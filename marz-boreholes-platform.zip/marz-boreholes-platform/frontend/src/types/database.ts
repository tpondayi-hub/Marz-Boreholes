// ============================================================
// AUTO-GENERATED: Run `supabase gen types typescript --local > src/types/database.ts`
// This is a simplified version for the Marz Boreholes platform
// ============================================================

export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          email: string
          full_name: string
          phone: string
          role: 'admin' | 'dispatcher' | 'technician' | 'client'
          avatar_url: string | null
          employee_id: string | null
          base_location: unknown | null
          current_status: 'available' | 'en_route' | 'on_site' | 'off_duty'
          current_job_id: string | null
          rating: number
          jobs_completed: number
          preferences: Json
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name: string
          phone: string
          role?: 'admin' | 'dispatcher' | 'technician' | 'client'
          avatar_url?: string | null
          employee_id?: string | null
          base_location?: unknown | null
          current_status?: 'available' | 'en_route' | 'on_site' | 'off_duty'
          current_job_id?: string | null
          rating?: number
          jobs_completed?: number
          preferences?: Json
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string
          phone?: string
          role?: 'admin' | 'dispatcher' | 'technician' | 'client'
          avatar_url?: string | null
          employee_id?: string | null
          base_location?: unknown | null
          current_status?: 'available' | 'en_route' | 'on_site' | 'off_duty'
          current_job_id?: string | null
          rating?: number
          jobs_completed?: number
          preferences?: Json
          created_at?: string
          updated_at?: string
        }
      }
      jobs: {
        Row: {
          id: string
          reference_number: string
          property_id: string
          technician_id: string | null
          type: 'installation' | 'repair' | 'maintenance' | 'water_test' | 'assessment' | 'emergency'
          urgency: 'emergency' | 'high' | 'medium' | 'low' | 'planning'
          status: 'pending' | 'dispatched' | 'en_route' | 'on_site' | 'completed' | 'cancelled'
          description: string
          scheduled_date: string | null
          estimated_duration_minutes: number | null
          actual_start: string | null
          actual_end: string | null
          customer_rating: number | null
          technician_notes: string | null
          materials_cost: number
          labor_cost: number
          total_cost: number
          invoice_id: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          reference_number?: string
          property_id: string
          technician_id?: string | null
          type: 'installation' | 'repair' | 'maintenance' | 'water_test' | 'assessment' | 'emergency'
          urgency?: 'emergency' | 'high' | 'medium' | 'low' | 'planning'
          status?: 'pending' | 'dispatched' | 'en_route' | 'on_site' | 'completed' | 'cancelled'
          description: string
          scheduled_date?: string | null
          estimated_duration_minutes?: number | null
          actual_start?: string | null
          actual_end?: string | null
          customer_rating?: number | null
          technician_notes?: string | null
          materials_cost?: number
          labor_cost?: number
          total_cost?: number
          invoice_id?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          reference_number?: string
          property_id?: string
          technician_id?: string | null
          type?: 'installation' | 'repair' | 'maintenance' | 'water_test' | 'assessment' | 'emergency'
          urgency?: 'emergency' | 'high' | 'medium' | 'low' | 'planning'
          status?: 'pending' | 'dispatched' | 'en_route' | 'on_site' | 'completed' | 'cancelled'
          description?: string
          scheduled_date?: string | null
          estimated_duration_minutes?: number | null
          actual_start?: string | null
          actual_end?: string | null
          customer_rating?: number | null
          technician_notes?: string | null
          materials_cost?: number
          labor_cost?: number
          total_cost?: number
          invoice_id?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      properties: {
        Row: {
          id: string
          owner_id: string
          name: string
          address: string
          suburb: string
          city: string
          type: 'residential' | 'commercial' | 'industrial' | 'agricultural'
          size_hectares: number | null
          estimated_value: number | null
          gps_location: unknown | null
          access_notes: string | null
          gate_code: string | null
          created_at: string
        }
        Insert: {
          id?: string
          owner_id: string
          name: string
          address: string
          suburb: string
          city: string
          type: 'residential' | 'commercial' | 'industrial' | 'agricultural'
          size_hectares?: number | null
          estimated_value?: number | null
          gps_location?: unknown | null
          access_notes?: string | null
          gate_code?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          owner_id?: string
          name?: string
          address?: string
          suburb?: string
          city?: string
          type?: 'residential' | 'commercial' | 'industrial' | 'agricultural'
          size_hectares?: number | null
          estimated_value?: number | null
          gps_location?: unknown | null
          access_notes?: string | null
          gate_code?: string | null
          created_at?: string
        }
      }
      assessments: {
        Row: {
          id: string
          reference: string
          contact_name: string
          contact_phone: string
          contact_email: string | null
          preferred_contact: 'whatsapp' | 'email' | 'sms' | 'phone'
          property_address: string
          suburb: string
          city: string
          property_type: 'residential' | 'commercial' | 'industrial' | 'agricultural'
          size_hectares: number | null
          estimated_value: number | null
          issue_category: string
          urgency: 'emergency' | 'high' | 'medium' | 'low' | 'planning'
          description: string
          has_existing_borehole: boolean
          borehole_depth: number | null
          pump_type: string | null
          pump_age: number | null
          last_service_date: string | null
          has_filtration: boolean
          has_storage_tank: boolean
          lead_score: number | null
          status: 'new' | 'contacted' | 'scheduled' | 'converted' | 'closed'
          converted_job_id: string | null
          consent: boolean
          created_at: string
        }
        Insert: {
          id?: string
          reference?: string
          contact_name: string
          contact_phone: string
          contact_email?: string | null
          preferred_contact?: 'whatsapp' | 'email' | 'sms' | 'phone'
          property_address: string
          suburb: string
          city: string
          property_type?: 'residential' | 'commercial' | 'industrial' | 'agricultural'
          size_hectares?: number | null
          estimated_value?: number | null
          issue_category: string
          urgency?: 'emergency' | 'high' | 'medium' | 'low' | 'planning'
          description: string
          has_existing_borehole?: boolean
          borehole_depth?: number | null
          pump_type?: string | null
          pump_age?: number | null
          last_service_date?: string | null
          has_filtration?: boolean
          has_storage_tank?: boolean
          lead_score?: number | null
          status?: 'new' | 'contacted' | 'scheduled' | 'converted' | 'closed'
          converted_job_id?: string | null
          consent: boolean
          created_at?: string
        }
        Update: {
          id?: string
          reference?: string
          contact_name?: string
          contact_phone?: string
          contact_email?: string | null
          preferred_contact?: 'whatsapp' | 'email' | 'sms' | 'phone'
          property_address?: string
          suburb?: string
          city?: string
          property_type?: 'residential' | 'commercial' | 'industrial' | 'agricultural'
          size_hectares?: number | null
          estimated_value?: number | null
          issue_category?: string
          urgency?: 'emergency' | 'high' | 'medium' | 'low' | 'planning'
          description?: string
          has_existing_borehole?: boolean
          borehole_depth?: number | null
          pump_type?: string | null
          pump_age?: number | null
          last_service_date?: string | null
          has_filtration?: boolean
          has_storage_tank?: boolean
          lead_score?: number | null
          status?: 'new' | 'contacted' | 'scheduled' | 'converted' | 'closed'
          converted_job_id?: string | null
          consent?: boolean
          created_at?: string
        }
      }
    }
  }
}

export type Tables<T extends keyof Database['public']['Tables']> = Database['public']['Tables'][T]['Row']
export type Enums<T extends keyof Database['public']['Enums']> = Database['public']['Enums'][T]
