/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#0066CC',
          dark: '#004C99',
          light: '#E8F4FD',
        },
        secondary: {
          DEFAULT: '#00AA66',
          dark: '#008855',
          light: '#E8F5E9',
        },
        accent: {
          DEFAULT: '#FF6B35',
          light: '#FFF3E0',
        },
        danger: {
          DEFAULT: '#DC3545',
          light: '#FFEBEE',
        },
        warning: {
          DEFAULT: '#FFC107',
        },
        success: {
          DEFAULT: '#28A745',
        },
        info: {
          DEFAULT: '#17A2B8',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', '-apple-system', 'sans-serif'],
      },
      animation: {
        'pulse-ring': 'pulse-ring 2s infinite',
        'slide-up': 'slideUp 0.4s ease-out forwards',
        'slide-in-right': 'slideInRight 0.4s ease-out forwards',
      },
      keyframes: {
        'pulse-ring': {
          '0%, 100%': { boxShadow: '0 0 0 4px rgba(0,102,204,0.3)' },
          '50%': { boxShadow: '0 0 0 12px rgba(0,102,204,0.1)' },
        },
        slideUp: {
          from: { opacity: '0', transform: 'translateY(20px)' },
          to: { opacity: '1', transform: 'translateY(0)' },
        },
        slideInRight: {
          from: { opacity: '0', transform: 'translateX(30px)' },
          to: { opacity: '1', transform: 'translateX(0)' },
        },
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
  ],
}
