-- ============================================================
-- MARZ BOREHOLES - SEED DATA
-- ============================================================
-- Run this after supabase_setup.sql and supabase_auth_security.sql
-- Creates realistic demo data for development and testing
--
-- WARNING: Only run in development/staging environments!
-- ============================================================

-- Clear existing data (cascade delete handles dependencies)
TRUNCATE TABLE public.notifications CASCADE;
TRUNCATE TABLE public.job_timeline CASCADE;
TRUNCATE TABLE public.job_checklist_items CASCADE;
TRUNCATE TABLE public.job_materials CASCADE;
TRUNCATE TABLE public.job_photos CASCADE;
TRUNCATE TABLE public.jobs CASCADE;
TRUNCATE TABLE public.invoices CASCADE;
TRUNCATE TABLE public.subscriptions CASCADE;
TRUNCATE TABLE public.water_quality_reports CASCADE;
TRUNCATE TABLE public.pumps CASCADE;
TRUNCATE TABLE public.boreholes CASCADE;
TRUNCATE TABLE public.assessments CASCADE;
TRUNCATE TABLE public.certifications CASCADE;
TRUNCATE TABLE public.properties CASCADE;
TRUNCATE TABLE public.users CASCADE;

-- ============================================================
-- USERS (Technicians + Clients + Admin)
-- ============================================================

-- Admin
INSERT INTO public.users (id, email, full_name, phone, role, employee_id, rating, jobs_completed, preferences, created_at) VALUES
('a0000000-0000-0000-0000-000000000001', 'admin@marzboreholes.co.za', 'John Doe', '+27 71 000 0001', 'admin', 'MARZ-ADM-0001', 0, 0, '{"theme": "dark", "notifications": true}', NOW());

-- Dispatchers
INSERT INTO public.users (id, email, full_name, phone, role, employee_id, rating, jobs_completed, preferences, created_at) VALUES
('d0000000-0000-0000-0000-000000000001', 'dispatch@marzboreholes.co.za', 'Jane Smith', '+27 71 000 0002', 'dispatcher', 'MARZ-DIS-0001', 0, 0, '{"theme": "light", "notifications": true}', NOW());

-- Technicians
INSERT INTO public.users (id, email, full_name, phone, role, employee_id, current_status, rating, jobs_completed, preferences, created_at) VALUES
('t0000000-0000-0000-0000-000000000001', 'thabo@marzboreholes.co.za', 'Thabo Mokoena', '+27 72 345 6789', 'technician', 'MARZ-TECH-0042', 'available', 9.8, 156, '{"push_enabled": true, "whatsapp_notifications": true, "sms_notifications": false, "gps_enabled": true, "auto_accept_emergency": true, "weekend_available": false}', NOW()),
('t0000000-0000-0000-0000-000000000002', 'pieter@marzboreholes.co.za', 'Pieter van der Merwe', '+27 72 456 7890', 'technician', 'MARZ-TECH-0018', 'available', 9.5, 138, '{"push_enabled": true, "whatsapp_notifications": true, "sms_notifications": true, "gps_enabled": true, "auto_accept_emergency": false, "weekend_available": true}', NOW()),
('t0000000-0000-0000-0000-000000000003', 'john@marzboreholes.co.za', 'John Le Roux', '+27 72 567 8901', 'technician', 'MARZ-TECH-0025', 'on_site', 9.2, 124, '{"push_enabled": true, "whatsapp_notifications": false, "sms_notifications": false, "gps_enabled": true, "auto_accept_emergency": true, "weekend_available": false}', NOW()),
('t0000000-0000-0000-0000-000000000004', 'sarah@marzboreholes.co.za', 'Sarah Khumalo', '+27 72 678 9012', 'technician', 'MARZ-TECH-0031', 'off_duty', 9.0, 112, '{"push_enabled": true, "whatsapp_notifications": true, "sms_notifications": true, "gps_enabled": true, "auto_accept_emergency": false, "weekend_available": true}', NOW());

-- Clients
INSERT INTO public.users (id, email, full_name, phone, role, preferences, created_at) VALUES
('c0000000-0000-0000-0000-000000000001', 'sarah.johnson@email.com', 'Sarah Johnson', '+27 72 111 2222', 'client', '{"notifications": true, "preferred_contact": "whatsapp"}', NOW()),
('c0000000-0000-0000-0000-000000000002', 'michael.chen@email.com', 'Michael Chen', '+27 72 222 3333', 'client', '{"notifications": true, "preferred_contact": "email"}', NOW()),
('c0000000-0000-0000-0000-000000000003', 'david.pretorius@email.com', 'David Pretorius', '+27 72 333 4444', 'client', '{"notifications": true, "preferred_contact": "phone"}', NOW()),
('c0000000-0000-0000-0000-000000000004', 'lisa.mokoena@email.com', 'Lisa Mokoena', '+27 72 444 5555', 'client', '{"notifications": false, "preferred_contact": "sms"}', NOW());

-- ============================================================
-- CERTIFICATIONS
-- ============================================================

INSERT INTO public.certifications (technician_id, name, issuer, issue_date, expiry_date, verified) VALUES
('t0000000-0000-0000-0000-000000000001', 'SANS 241 Water Quality', 'SA Water Institute', '2023-12-15', '2025-12-15', TRUE),
('t0000000-0000-0000-0000-000000000001', 'Electrical Compliance (CoC)', 'ECSA', '2022-03-03', '2025-03-03', TRUE),
('t0000000-0000-0000-0000-000000000001', 'Grundfos Certified Installer', 'Grundfos SA', '2023-08-18', '2025-08-18', TRUE),
('t0000000-0000-0000-0000-000000000002', 'SANS 241 Water Quality', 'SA Water Institute', '2024-01-20', '2026-01-20', TRUE),
('t0000000-0000-0000-0000-000000000002', 'Franklin Electric Certified', 'Franklin Electric', '2023-05-10', '2025-05-10', TRUE),
('t0000000-0000-0000-0000-000000000003', 'Solar Pump Systems', 'SolarTech SA', '2023-09-01', '2025-09-01', TRUE),
('t0000000-0000-0000-0000-000000000004', 'Water Quality Testing', 'SA Water Institute', '2024-02-15', '2026-02-15', TRUE);

-- ============================================================
-- PROPERTIES
-- ============================================================

INSERT INTO public.properties (id, owner_id, name, address, suburb, city, type, size_hectares, estimated_value, access_notes, gate_code, created_at) VALUES
('p0000000-0000-0000-0000-000000000001', 'c0000000-0000-0000-0000-000000000001', 'Johnson Residence', '15 Maple Drive', 'Sandton', 'Johannesburg', 'residential', 0.5, 4500000, 'Park in driveway. Dogs friendly.', '4721', NOW()),
('p0000000-0000-0000-0000-000000000002', 'c0000000-0000-0000-0000-000000000002', 'Chen Logistics Warehouse', '77 Industrial Boulevard', 'Centurion', 'Pretoria', 'commercial', 2.5, 8500000, 'Gate 3. Security check required.', '7842', NOW()),
('p0000000-0000-0000-0000-000000000003', 'c0000000-0000-0000-0000-000000000003', 'Pretorius Farm', '128 Riverside Estate', 'Midrand', 'Johannesburg', 'agricultural', 12.0, 12000000, 'Main gate, second dirt road.', '1298', NOW()),
('p0000000-0000-0000-0000-000000000004', 'c0000000-0000-0000-0000-000000000004', 'Mokoena Family Home', '42 Oak Avenue', 'Midrand', 'Johannesburg', 'residential', 0.8, 3500000, 'Intercom at gate. Ring twice.', '3366', NOW());

-- ============================================================
-- BOREHOLES
-- ============================================================

INSERT INTO public.boreholes (id, property_id, depth_meters, yield_lph, drill_date, status, created_at) VALUES
('b0000000-0000-0000-0000-000000000001', 'p0000000-0000-0000-0000-000000000001', 85.0, 2400, '2019-03-15', 'active', NOW()),
('b0000000-0000-0000-0000-000000000002', 'p0000000-0000-0000-0000-000000000002', 120.0, 3600, '2021-07-22', 'active', NOW()),
('b0000000-0000-0000-0000-000000000003', 'p0000000-0000-0000-0000-000000000003', 150.0, 4800, '2020-11-08', 'active', NOW()),
('b0000000-0000-0000-0000-000000000004', 'p0000000-0000-0000-0000-000000000004', 72.0, 1800, '2022-05-30', 'active', NOW());

-- ============================================================
-- PUMPS
-- ============================================================

INSERT INTO public.pumps (id, borehole_id, type, brand, model, horsepower, install_date, warranty_expiry, last_service_date, status, created_at) VALUES
('pu000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 'Submersible', 'Grundfos', 'SP5A-9', 1.5, '2019-04-01', '2024-04-01', '2024-03-15', 'operational', NOW()),
('pu000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', 'Submersible', 'Franklin Electric', '4-inch', 2.0, '2021-08-15', '2026-08-15', '2024-05-20', 'operational', NOW()),
('pu000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 'Solar', 'Lorentz', 'PS2-600', 0.8, '2022-01-10', '2027-01-10', '2024-04-10', 'operational', NOW()),
('pu000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000004', 'Submersible', 'Grundfos', 'SP3A-5', 1.0, '2022-06-15', '2027-06-15', '2024-02-28', 'operational', NOW());

-- ============================================================
-- JOBS
-- ============================================================

INSERT INTO public.jobs (id, reference_number, property_id, technician_id, type, urgency, status, description, scheduled_date, estimated_duration_minutes, actual_start, actual_end, customer_rating, technician_notes, materials_cost, labor_cost, total_cost, created_at, updated_at) VALUES
('j0000000-0000-0000-0000-000000000001', 'MARZ-2024-00042', 'p0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'maintenance', 'medium', 'completed', 'Quarterly maintenance - pump inspection, electrical test, water sample.', '2024-06-14 08:00:00', 120, '2024-06-14 08:05:00', '2024-06-14 10:15:00', 10, 'All systems nominal. Pump drawing 8.2A. Pressure stable at 3.2 bar. Water clear, no sediment.', 0, 1200, 1200, NOW(), NOW()),
('j0000000-0000-0000-0000-000000000002', 'MARZ-2024-00043', 'p0000000-0000-0000-0000-000000000004', 't0000000-0000-0000-0000-000000000001', 'emergency', 'emergency', 'completed', 'No water from borehole for 2 days. Pump makes humming noise but no water flow. Electrical breaker trips occasionally.', '2024-06-14 10:30:00', 180, '2024-06-14 10:35:00', '2024-06-14 13:20:00', 8, 'Replaced faulty pressure switch. Pump drawing normal current. Pressure stable at 3.2 bar. Water clear.', 1850, 1000, 2850, NOW(), NOW()),
('j0000000-0000-0000-0000-000000000003', 'MARZ-2024-00044', 'p0000000-0000-0000-0000-000000000002', 't0000000-0000-0000-0000-000000000002', 'water_test', 'low', 'completed', 'Quarterly water test due. Previous test showed elevated iron levels. Need comprehensive SANS 241 analysis.', '2024-06-14 14:00:00', 90, '2024-06-14 14:05:00', '2024-06-14 15:30:00', 9, 'All parameters within SANS 241 limits. Iron levels normal. pH 7.2, TDS 285, turbidity 0.8, E.Coli 0.', 450, 0, 450, NOW(), NOW()),
('j0000000-0000-0000-0000-000000000004', 'MARZ-2024-00045', 'p0000000-0000-0000-0000-000000000003', 't0000000-0000-0000-0000-000000000003', 'installation', 'high', 'completed', 'New borehole drilled last week. Need submersible pump installation. 85m depth, 2,400L/hr yield.', '2024-06-13 09:00:00', 240, '2024-06-13 09:00:00', '2024-06-13 13:00:00', 10, 'Installed Grundfos SP5A-9 submersible pump. 85m depth, 2,400L/hr yield. New pressure switch and 50m cable. 2-year warranty.', 12500, 6000, 18500, NOW(), NOW()),
('j0000000-0000-0000-0000-000000000005', 'MARZ-2024-00046', 'p0000000-0000-0000-0000-000000000001', 't0000000-0000-0000-0000-000000000001', 'maintenance', 'medium', 'scheduled', 'Quarterly maintenance - Johnson Residence. Pump inspection, electrical test, water sample.', '2024-06-21 09:00:00', 120, NULL, NULL, NULL, NULL, 0, 1200, 1200, NOW(), NOW()),
('j0000000-0000-0000-0000-000000000006', 'MARZ-2024-00047', 'p0000000-0000-0000-0000-000000000002', 't0000000-0000-0000-0000-000000000002', 'repair', 'high', 'pending', 'Pump not starting. Control panel shows error E-05. Possible electrical fault.', '2024-06-20 08:00:00', 180, NULL, NULL, NULL, NULL, 0, 0, 0, NOW(), NOW()),
('j0000000-0000-0000-0000-000000000007', 'MARZ-2024-00048', 'p0000000-0000-0000-0000-000000000004', NULL, 'assessment', 'low', 'pending', 'New installation inquiry. Property has no existing borehole. Interested in solar pump system.', '2024-06-25 10:00:00', 60, NULL, NULL, NULL, NULL, 0, 0, 0, NOW(), NOW());

-- ============================================================
-- JOB CHECKLIST ITEMS
-- ============================================================

INSERT INTO public.job_checklist_items (job_id, category, item, completed, completed_at, notes) VALUES
('j0000000-0000-0000-0000-000000000002', 'Electrical', 'Electrical test completed', TRUE, '2024-06-14 11:00:00', 'All circuits normal, no shorts'),
('j0000000-0000-0000-0000-000000000002', 'Pressure', 'Pressure test (3.2 bar OK)', TRUE, '2024-06-14 11:30:00', 'Within spec 3.0-4.5 bar'),
('j0000000-0000-0000-0000-000000000002', 'Water', 'Water sample collected', TRUE, '2024-06-14 12:00:00', 'Clear, no sediment'),
('j0000000-0000-0000-0000-000000000002', 'Visual', 'Visual inspection', TRUE, '2024-06-14 12:30:00', 'No visible damage to casing'),
('j0000000-0000-0000-0000-000000000002', 'Performance', 'Pump performance check', TRUE, '2024-06-14 13:00:00', 'Drawing 8.2A, normal range'),
('j0000000-0000-0000-0000-000000000002', 'Safety', 'Safety check', TRUE, '2024-06-14 13:15:00', 'All guards in place, earth connection good');

-- ============================================================
-- JOB MATERIALS
-- ============================================================

INSERT INTO public.job_materials (job_id, name, quantity, unit, unit_cost, total_cost) VALUES
('j0000000-0000-0000-0000-000000000002', 'Pressure Switch (new)', 1, 'unit', 450.00, 450.00),
('j0000000-0000-0000-0000-000000000002', '4mm² Cable', 5, 'meters', 45.00, 225.00),
('j0000000-0000-0000-0000-000000000002', 'Electrical Tape', 2, 'rolls', 35.00, 70.00),
('j0000000-0000-0000-0000-000000000002', 'Cable Glands', 4, 'units', 25.00, 100.00),
('j0000000-0000-0000-0000-000000000002', 'Silicone Sealant', 1, 'tube', 85.00, 85.00),
('j0000000-0000-0000-0000-000000000002', 'Labour - Emergency Rate', 2, 'hours', 500.00, 1000.00),
('j0000000-0000-0000-0000-000000000004', 'Grundfos SP5A-9 Pump', 1, 'unit', 8500.00, 8500.00),
('j0000000-0000-0000-0000-000000000004', '4mm² Cable - 50m', 1, 'roll', 1200.00, 1200.00),
('j0000000-0000-0000-0000-000000000004', 'Pressure Switch', 1, 'unit', 450.00, 450.00),
('j0000000-0000-0000-0000-000000000004', 'Installation Labour', 6, 'hours', 600.00, 3600.00);

-- ============================================================
-- WATER QUALITY REPORTS
-- ============================================================

INSERT INTO public.water_quality_reports (id, borehole_id, ph, tds_mg_l, turbidity, e_coli, nitrates, iron, tested_by, test_date, lab, compliant, created_at) VALUES
('w0000000-0000-0000-0000-000000000001', 'b0000000-0000-0000-0000-000000000001', 7.2, 285, 0.8, 0, 2.5, 0.15, 't0000000-0000-0000-0000-000000000004', '2024-06-05', 'SA Water Lab', TRUE, NOW()),
('w0000000-0000-0000-0000-000000000002', 'b0000000-0000-0000-0000-000000000002', 6.8, 420, 1.2, 0, 4.1, 0.35, 't0000000-0000-0000-0000-000000000004', '2024-05-20', 'SA Water Lab', TRUE, NOW()),
('w0000000-0000-0000-0000-000000000003', 'b0000000-0000-0000-0000-000000000003', 7.5, 180, 0.5, 0, 1.8, 0.08, 't0000000-0000-0000-0000-000000000004', '2024-04-10', 'SA Water Lab', TRUE, NOW()),
('w0000000-0000-0000-0000-000000000004', 'b0000000-0000-0000-0000-000000000001', 7.1, 310, 0.9, 0, 2.8, 0.22, 't0000000-0000-0000-0000-000000000004', '2024-03-15', 'SA Water Lab', TRUE, NOW());

-- ============================================================
-- INVOICES
-- ============================================================

INSERT INTO public.invoices (id, job_id, property_id, invoice_number, issue_date, due_date, subtotal, tax_rate, tax_amount, total, amount_paid, status, created_at) VALUES
('i0000000-0000-0000-0000-000000000001', 'j0000000-0000-0000-0000-000000000001', 'p0000000-0000-0000-0000-000000000001', 'INV-2024-0042', '2024-06-14', '2024-07-14', 1200.00, 15.00, 180.00, 1380.00, 1380.00, 'paid', NOW()),
('i0000000-0000-0000-0000-000000000002', 'j0000000-0000-0000-0000-000000000002', 'p0000000-0000-0000-0000-000000000004', 'INV-2024-0043', '2024-06-14', '2024-07-14', 2850.00, 15.00, 427.50, 3277.50, 3277.50, 'paid', NOW()),
('i0000000-0000-0000-0000-000000000003', 'j0000000-0000-0000-0000-000000000003', 'p0000000-0000-0000-0000-000000000002', 'INV-2024-0044', '2024-06-14', '2024-07-14', 450.00, 15.00, 67.50, 517.50, 517.50, 'paid', NOW()),
('i0000000-0000-0000-0000-000000000004', 'j0000000-0000-0000-0000-000000000004', 'p0000000-0000-0000-0000-000000000003', 'INV-2024-0045', '2024-06-13', '2024-07-13', 18500.00, 15.00, 2775.00, 21275.00, 21275.00, 'paid', NOW()),
('i0000000-0000-0000-0000-000000000005', 'j0000000-0000-0000-0000-000000000005', 'p0000000-0000-0000-0000-000000000001', 'INV-2024-0046', '2024-06-21', '2024-07-21', 1200.00, 15.00, 180.00, 1380.00, 0.00, 'draft', NOW());

-- ============================================================
-- SUBSCRIPTIONS
-- ============================================================

INSERT INTO public.subscriptions (id, property_id, plan_id, status, start_date, next_billing_date, payment_method, created_at) VALUES
('s0000000-0000-0000-0000-000000000001', 'p0000000-0000-0000-0000-000000000001', (SELECT id FROM public.plans WHERE name = 'Marz Pro'), 'active', '2024-01-01', '2024-07-01', 'credit_card', NOW()),
('s0000000-0000-0000-0000-000000000002', 'p0000000-0000-0000-0000-000000000002', (SELECT id FROM public.plans WHERE name = 'Marz Enterprise'), 'active', '2023-06-01', '2024-07-01', 'debit_order', NOW()),
('s0000000-0000-0000-0000-000000000003', 'p0000000-0000-0000-0000-000000000003', (SELECT id FROM public.plans WHERE name = 'Marz Basic'), 'active', '2024-03-01', '2024-07-01', 'credit_card', NOW());

-- ============================================================
-- ASSESSMENTS
-- ============================================================

INSERT INTO public.assessments (id, reference, contact_name, contact_phone, contact_email, preferred_contact, property_address, suburb, city, property_type, size_hectares, estimated_value, issue_category, urgency, description, has_existing_borehole, borehole_depth, pump_type, pump_age, last_service_date, has_filtration, has_storage_tank, lead_score, status, consent, created_at) VALUES
('a0000000-0000-0000-0000-000000000001', 'AST-2024-00001', 'Michael Chen', '+27 72 345 6789', 'michael@example.com', 'whatsapp', '42 Oak Avenue, Riverside Estate', 'Midrand', 'Centurion', 'residential', 0.8, 3500000, 'No Water', 'emergency', 'No water from borehole for 2 days. Pump makes humming noise but no water flow. Electrical breaker trips occasionally. Pump is 8 years old, last serviced 14 months ago.', TRUE, 85.0, 'Grundfos Submersible', 8, '2023-04-15', FALSE, TRUE, 68, 'converted', TRUE, NOW()),
('a0000000-0000-0000-0000-000000000002', 'AST-2024-00002', 'Lisa Mokoena', '+27 72 444 5555', 'lisa@example.com', 'email', '128 Riverside Estate', 'Midrand', 'Johannesburg', 'residential', 0.8, 3500000, 'New Install', 'planning', 'Interested in installing a new borehole with solar pump system. Property is 0.8 hectares. No existing water infrastructure.', FALSE, NULL, NULL, NULL, NULL, FALSE, FALSE, 42, 'new', TRUE, NOW()),
('a0000000-0000-0000-0000-000000000003', 'AST-2024-00003', 'David Pretorius', '+27 72 333 4444', 'david@example.com', 'phone', 'Pretorius Farm, 128 Riverside', 'Midrand', 'Johannesburg', 'agricultural', 12.0, 12000000, 'Low Pressure', 'medium', 'Water pressure has been decreasing over the past month. Currently at 1.5 bar. Need pump performance check and possible upgrade.', TRUE, 150.0, 'Solar Pump', 3, '2024-01-10', FALSE, TRUE, 55, 'contacted', TRUE, NOW());

-- ============================================================
-- NOTIFICATIONS
-- ============================================================

INSERT INTO public.notifications (user_id, type, title, body, data, read, priority, created_at) VALUES
('t0000000-0000-0000-0000-000000000001', 'job_assigned', 'New Job Assigned', 'Emergency repair at 42 Oak Avenue, Midrand. No water for 2 days.', '{"job_id": "j0000000-0000-0000-0000-000000000002"}', TRUE, 'high', NOW() - INTERVAL '2 hours'),
('t0000000-0000-0000-0000-000000000001', 'status_update', 'Job Completed', 'Emergency repair completed. Customer rated 8/10.', '{"job_id": "j0000000-0000-0000-0000-000000000002"}', TRUE, 'normal', NOW() - INTERVAL '1 hour'),
('c0000000-0000-0000-0000-000000000002', 'job_assigned', 'Technician Assigned', 'Thabo Mokoena has been assigned to your emergency repair.', '{"job_id": "j0000000-0000-0000-0000-000000000002"}', TRUE, 'normal', NOW() - INTERVAL '3 hours'),
('c0000000-0000-0000-0000-000000000002', 'status_update', 'Job Completed', 'Your emergency repair has been completed. Total cost: R2,850.', '{"job_id": "j0000000-0000-0000-0000-000000000002"}', FALSE, 'normal', NOW() - INTERVAL '1 hour'),
('d0000000-0000-0000-0000-000000000001', 'emergency_alert', 'New Emergency Assessment', 'Michael Chen - No Water (Midrand) - Lead Score: 68', '{"assessment_id": "a0000000-0000-0000-0000-000000000001"}', FALSE, 'high', NOW() - INTERVAL '4 hours');

-- ============================================================
-- SEED COMPLETE
-- ============================================================

SELECT 'Seed data loaded successfully!' as status;
SELECT 'Users: 9 (1 admin, 1 dispatcher, 4 technicians, 3 clients)' as users;
SELECT 'Properties: 4' as properties;
SELECT 'Boreholes: 4' as boreholes;
SELECT 'Pumps: 4' as pumps;
SELECT 'Jobs: 7 (4 completed, 2 pending, 1 scheduled)' as jobs;
SELECT 'Invoices: 5 (4 paid, 1 draft)' as invoices;
SELECT 'Subscriptions: 3' as subscriptions;
SELECT 'Assessments: 3' as assessments;
SELECT 'Water Reports: 4' as water_reports;
SELECT 'Certifications: 7' as certifications;
SELECT 'Notifications: 5' as notifications;
