# Marz Boreholes Platform

A complete field service management platform for borehole drilling, pump installation, and water system maintenance companies. Built with mobile-first design for technicians in the field and comprehensive admin tools for dispatchers and managers.

## Platform Overview

| Role | Screens | Platform |
|------|---------|----------|
| **Technician** | Dashboard, In-Job Workflow, Profile | Mobile App (PWA) |
| **Client** | Dashboard, Service History, Booking | Mobile App / Web |
| **Dispatcher** | Dispatch Board, Scheduling Calendar, Analytics | Desktop Web |
| **Admin** | Analytics Dashboard, User Management, Settings | Desktop Web |
| **Public** | Expert Assessment (Lead Intake) | Mobile Web |

## Quick Start

All previews are self-contained HTML files. Simply open any `.html` file in a browser.

```bash
# Start from the index page
open index.html

# Or open any preview directly
open preview_technician_dashboard.html
```

> **Note:** Some previews load external resources from CDNs (Google Fonts, Font Awesome, Chart.js). An internet connection is required for full styling.

## File Structure

```
marz-boreholes-platform/
├── index.html                          # Navigation hub for all previews
│
├── preview_technician_dashboard.html     # Mobile: Daily schedule & stats
├── preview_injob_workflow.html         # Mobile: Job execution interface
├── preview_technician_profile.html     # Mobile: Profile, skills, availability
│
├── preview_client_dashboard.html       # Mobile: Customer portal
├── preview_service_history.html        # Mobile: Timeline of all services
│
├── preview_assessment_form.html        # Mobile Web: 5-step lead intake
│
├── preview_dispatch_board.html         # Desktop: Live map + dispatch queue
├── preview_booking_calendar.html       # Desktop: Week view scheduling
├── preview_analytics_dashboard.html    # Desktop: Charts & KPIs
│
├── api_routes.ts                       # Complete API specification
├── database_schema.md                  # ERD + SQL table definitions
└── design_system.md                    # Colors, typography, components
```

## UI Previews

### 1. Technician Dashboard (`preview_technician_dashboard.html`)
- Daily schedule with color-coded job cards
- Completion stats (done, pending, rating)
- GPS status indicator
- Quick actions for inventory and performance
- Bottom navigation (Schedule / Tools / Profile)

### 2. In-Job Workflow (`preview_injob_workflow.html`)
- 4-step status progress (Dispatched → Complete)
- Service checklist with tap-to-complete
- Photo documentation (before/during/after)
- Materials used logging
- Customer satisfaction rating (1-10)
- Offline-sync indicator

### 3. Expert Assessment Form (`preview_assessment_form.html`)
- 5-step progressive disclosure form
- Step 1: Contact info with preferred channel selection
- Step 2: Property details with type selector
- Step 3: Issue category + urgency level cards
- Step 4: Infrastructure with conditional fields
- Step 5: Review summary with lead score display
- JavaScript navigation between steps

### 4. Client Dashboard (`preview_client_dashboard.html`)
- Property cards with asset counts and lifetime value
- Water quality widget (pH, TDS, turbidity, E.Coli)
- Upcoming visits with technician tracking
- Marz Pro subscription plan banner
- Quick actions (Book Service, History, Reports, Plan)

### 5. Service History (`preview_service_history.html`)
- Timeline view with month grouping
- Color-coded job types (install, repair, maintenance, test)
- Embedded water quality reports
- Cost tracking and invoice buttons
- Customer ratings per job
- Lifetime spend summary

### 6. Dispatch Board (`preview_dispatch_board.html`)
- Sidebar navigation with active state
- Live stats cards (pending, completed, emergency, available)
- Interactive map with technician markers and pulse animation
- SVG route lines with animated progress dots
- Technician cards at bottom with availability status
- Priority-scored dispatch queue
- Auto/Manual assignment buttons
- Scoring breakdown (distance, skill, availability, urgency)

### 7. Booking Calendar (`preview_booking_calendar.html`)
- Week view with 7 days + time slots
- Color-coded event types
- Day/Week/Month view toggle
- Today's schedule panel
- Technician assignment per job
- Status indicators (confirmed/pending)

### 8. Analytics Dashboard (`preview_analytics_dashboard.html`)
- Chart.js integration (line + doughnut charts)
- Jobs & Revenue trend over time
- Service mix breakdown
- Technician leaderboard with progress bars
- Revenue by service type table
- Date range selector

### 9. Technician Profile (`preview_technician_profile.html`)
- Gradient header with avatar and status
- Stats cards (jobs, rating, experience)
- Personal info section
- Skills and specializations tags
- Certification cards with expiry status
- Availability calendar (month view)
- Preference toggles (emergency auto-accept, GPS, notifications)

## API Specification (`api_routes.ts`)

Complete REST API design with TypeScript interfaces:

- **Auth**: Login, register, refresh, logout
- **Users**: CRUD, technician profiles, skills
- **Properties**: Client asset management
- **Boreholes**: Infrastructure tracking
- **Jobs**: Full lifecycle from creation to completion
- **Dispatch**: Queue management, auto-assignment, live tracking
- **Assessments**: Lead intake and scoring
- **Water Quality**: SANS 241 compliance tracking
- **Invoices**: Billing and payment processing
- **Subscriptions**: Maintenance plan management
- **Analytics**: Dashboard data, technician stats, revenue reports
- **Notifications**: Push + WebSocket real-time

## Database Schema (`database_schema.md`)

Full relational schema with:

- **16 tables**: users, properties, boreholes, pumps, jobs, job_photos, job_materials, job_checklist_items, job_timeline, water_quality_reports, assessments, invoices, subscriptions, plans, certifications, notifications
- **Mermaid ERD diagram** showing all relationships
- **Complete column definitions** with types and constraints
- **Index recommendations** for performance
- **Row Level Security (RLS) policies** for multi-tenant access

## Design System (`design_system.md`)

Comprehensive design documentation:

- **Color palette**: 11 semantic tokens with usage patterns
- **Typography**: Inter font family with 7-level scale
- **Spacing**: 4px base unit system
- **Shadows**: 3 levels for depth hierarchy
- **Components**: Buttons, cards, inputs, badges, navigation, progress, toggles
- **Animations**: Entrance, micro-interactions, and continuous effects
- **Icons**: Font Awesome 6.4.0 with size and usage guidelines
- **Responsive breakpoints**: Mobile / Tablet / Desktop
- **Accessibility**: Contrast, focus states, touch targets, reduced motion

## Technology Stack

| Layer | Technology |
|-------|------------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Charts | Chart.js 4.4.1 |
| Icons | Font Awesome 6.4.0 |
| Fonts | Google Fonts (Inter) |
| Backend (planned) | Node.js / Supabase / PostgreSQL |
| Mobile (planned) | React Native or PWA |

## Key Features

### Mobile-First Technician Experience
- Offline-capable job workflows
- GPS tracking and route optimization
- Photo documentation with auto-upload
- Digital checklists and signatures
- Customer satisfaction capture

### Intelligent Dispatch
- Priority scoring algorithm (distance × skill × availability × urgency)
- Real-time technician location tracking
- Auto-assignment with manual override
- Live map visualization

### Client Self-Service
- Property and asset management
- Water quality report access
- Service history and invoices
- Maintenance plan subscriptions
- Direct booking and scheduling

### Lead Management
- 5-step expert assessment form
- Automatic lead scoring (0-100)
- Urgency-based response time estimation
- Conversion tracking to jobs

## Future Roadmap

- [ ] React Native mobile app
- [ ] Supabase backend integration
- [ ] Real-time WebSocket notifications
- [ ] Push notification service
- [ ] Payment gateway integration (PayFast)
- [ ] Route optimization (Google Maps API)
- [ ] Inventory management module
- [ ] Customer feedback surveys
- [ ] Multi-language support (English, Afrikaans, Zulu)
- [ ] White-label customization

## License

Built for demonstration purposes. All rights reserved.

---

**Marz Boreholes Platform** • Field Service Management for Water Systems
