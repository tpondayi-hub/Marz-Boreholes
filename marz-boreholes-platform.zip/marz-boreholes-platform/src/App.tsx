import React from 'react'
import { Routes, Route } from 'react-router-dom'
import { useAuthStateChange } from './hooks/useAuth'
import Layout from './components/Layout'
import Home from './pages/Home'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import JobDetail from './pages/JobDetail'
import DispatchBoard from './pages/DispatchBoard'
import AssessmentForm from './pages/AssessmentForm'
import TechnicianProfile from './pages/TechnicianProfile'
import ClientDashboard from './pages/ClientDashboard'
import ServiceHistory from './pages/ServiceHistory'
import Analytics from './pages/Analytics'
import BookingCalendar from './pages/BookingCalendar'
import ProtectedRoute from './components/ProtectedRoute'

function App() {
  useAuthStateChange()
  return (
    <Routes>
      <Route path="/" element={<Layout />}>
        <Route index element={<Home />} />
        <Route path="login" element={<Login />} />
        <Route path="assessment" element={<AssessmentForm />} />
        <Route path="dashboard" element={<ProtectedRoute allowedRoles={['technician','admin','dispatcher']}><Dashboard /></ProtectedRoute>} />
        <Route path="jobs/:id" element={<ProtectedRoute><JobDetail /></ProtectedRoute>} />
        <Route path="dispatch" element={<ProtectedRoute allowedRoles={['admin','dispatcher']}><DispatchBoard /></ProtectedRoute>} />
        <Route path="profile" element={<ProtectedRoute allowedRoles={['technician']}><TechnicianProfile /></ProtectedRoute>} />
        <Route path="client" element={<ProtectedRoute allowedRoles={['client']}><ClientDashboard /></ProtectedRoute>} />
        <Route path="history" element={<ProtectedRoute allowedRoles={['client']}><ServiceHistory /></ProtectedRoute>} />
        <Route path="analytics" element={<ProtectedRoute allowedRoles={['admin','dispatcher']}><Analytics /></ProtectedRoute>} />
        <Route path="calendar" element={<ProtectedRoute allowedRoles={['admin','dispatcher']}><BookingCalendar /></ProtectedRoute>} />
      </Route>
    </Routes>
  )
}

export default App
