export default function JobDetail() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Job Detail</h1></div>
}