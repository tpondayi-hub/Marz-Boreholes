export default function ClientDashboard() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Client Dashboard</h1></div>
}