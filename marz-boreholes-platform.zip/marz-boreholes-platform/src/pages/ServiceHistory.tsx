export default function ServiceHistory() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Service History</h1></div>
}