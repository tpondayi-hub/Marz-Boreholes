export default function DispatchBoard() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Dispatch Board</h1></div>
}