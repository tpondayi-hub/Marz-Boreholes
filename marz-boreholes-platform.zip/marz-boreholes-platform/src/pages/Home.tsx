export default function Home() {
  return <div className="p-8 text-center"><h1 className="text-3xl font-bold">Marz Boreholes</h1><p>Welcome to the platform</p></div>
}