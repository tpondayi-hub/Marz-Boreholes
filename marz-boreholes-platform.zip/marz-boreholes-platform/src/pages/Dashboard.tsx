export default function Dashboard() {
  return <div className="p-8"><h1 className="text-2xl font-bold">Technician Dashboard</h1></div>
}