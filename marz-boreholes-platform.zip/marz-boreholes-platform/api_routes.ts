// ============================================================
// MARZ BOREHOLES PLATFORM - API ROUTE SPECIFICATION
// ============================================================
// Base URL: /api/v1
// Authentication: Bearer JWT token required for all routes
// Rate Limit: 100 requests/minute per user
//
// Authentication Endpoints
// ============================================================

POST /auth/login
  Body: { email: string, password: string, device_id?: string }
  Response: { token: string, refresh_token: string, user: User, expires_at: ISO8601 }

POST /auth/register
  Body: { email: string, password: string, full_name: string, phone: string, role: 'client' | 'technician' }
  Response: { token: string, user: User }

POST /auth/refresh
  Body: { refresh_token: string }
  Response: { token: string, expires_at: ISO8601 }

POST /auth/logout
  Headers: Authorization: Bearer {token}
  Response: { success: true }

// ============================================================
// User Management
// ============================================================

GET /users/me
  Response: { id: UUID, email: string, full_name: string, phone: string, role: string, avatar_url?: string, created_at: ISO8601 }

PATCH /users/me
  Body: { full_name?: string, phone?: string, avatar_url?: string, preferences?: UserPreferences }
  Response: { user: User }

GET /users/technicians
  Query: ?status=available|busy|offline&skill=pump_install&limit=20&offset=0
  Response: { technicians: Technician[], total: number }

GET /users/technicians/:id
  Response: { technician: Technician, stats: TechnicianStats, certifications: Certification[], reviews: Review[] }

// ============================================================
// Properties (Client Assets)
// ============================================================

GET /properties
  Response: { properties: Property[], total: number }

POST /properties
  Body: { name: string, address: string, suburb: string, city: string, type: 'residential'|'commercial'|'industrial'|'agricultural', size_hectares?: number, estimated_value?: number }
  Response: { property: Property }

GET /properties/:id
  Response: { property: Property, boreholes: Borehole[], service_history: ServiceRecord[], water_quality: WaterQualityReport[] }

PATCH /properties/:id
  Body: Partial<Property>
  Response: { property: Property }

DELETE /properties/:id
  Response: { success: true }

// ============================================================
// Boreholes & Infrastructure
// ============================================================

GET /properties/:property_id/boreholes
  Response: { boreholes: Borehole[] }

POST /properties/:property_id/boreholes
  Body: { depth_meters: number, yield_lph: number, pump_type: string, pump_install_date: ISO8601, last_service_date?: ISO8601 }
  Response: { borehole: Borehole }

GET /boreholes/:id
  Response: { borehole: Borehole, pump: Pump, service_history: ServiceRecord[], water_tests: WaterQualityReport[] }

// ============================================================
// Jobs / Service Requests
// ============================================================

GET /jobs
  Query: ?status=pending|dispatched|en_route|on_site|completed|cancelled&technician_id=UUID&property_id=UUID&from=ISO8601&to=ISO8601&limit=20&offset=0
  Response: { jobs: Job[], total: number, stats: JobStats }

POST /jobs
  Body: { property_id: UUID, type: JobType, urgency: 'emergency'|'high'|'medium'|'low'|'planning', description: string, preferred_date?: ISO8601, photos?: string[] }
  Response: { job: Job, reference_number: string }

GET /jobs/:id
  Response: { job: Job, property: Property, technician?: Technician, timeline: JobTimeline[], photos: Photo[], materials: Material[], checklist: ChecklistItem[] }

PATCH /jobs/:id
  Body: Partial<Job>
  Response: { job: Job }

POST /jobs/:id/status
  Body: { status: JobStatus, location?: { lat: number, lng: number }, notes?: string, timestamp: ISO8601 }
  Response: { job: Job, timeline_entry: JobTimeline }

// ============================================================
// Dispatch & Scheduling
// ============================================================

GET /dispatch/queue
  Response: { queue: DispatchJob[], auto_assign_enabled: boolean, last_updated: ISO8601 }

POST /dispatch/assign
  Body: { job_id: UUID, technician_id: UUID, method: 'auto'|'manual', reason?: string }
  Response: { job: Job, technician: Technician, estimated_arrival: ISO8601 }

GET /dispatch/technicians/live
  Response: { technicians: LiveTechnician[], last_updated: ISO8601 }

GET /dispatch/optimize
  Query: ?job_id=UUID
  Response: { recommendations: TechnicianRecommendation[], factors: ScoringFactors }

// ============================================================
// Technician Job Execution (Mobile)
// ============================================================

GET /jobs/:id/checklist
  Response: { checklist: ChecklistItem[] }

POST /jobs/:id/checklist/:item_id
  Body: { completed: boolean, notes?: string, photos?: string[] }
  Response: { checklist_item: ChecklistItem }

POST /jobs/:id/photos
  Body: { type: 'before'|'during'|'after', url: string, metadata?: PhotoMetadata }
  Response: { photo: Photo }

POST /jobs/:id/materials
  Body: { items: { name: string, quantity: number, unit: string, cost?: number }[] }
  Response: { materials: Material[], total_cost: number }

POST /jobs/:id/complete
  Body: { customer_rating: number, technician_notes: string, materials_used: Material[], next_service_recommended?: ISO8601 }
  Response: { job: Job, invoice?: Invoice }

// ============================================================
// Expert Assessment (Lead Intake)
// ============================================================

POST /assessments
  Body: { contact: ContactInfo, property: PropertyInfo, issue: IssueDetails, infrastructure?: InfrastructureInfo, consent: boolean }
  Response: { assessment: Assessment, lead_score: number, estimated_response_time: string, reference: string }

GET /assessments/:id
  Response: { assessment: Assessment, lead_score: number, status: 'new'|'contacted'|'scheduled'|'converted'|'closed' }

GET /assessments
  Query: ?status=new&limit=20&offset=0
  Response: { assessments: Assessment[], total: number }

// ============================================================
// Water Quality Reports
// ============================================================

GET /water-quality
  Query: ?property_id=UUID&borehole_id=UUID&limit=10
  Response: { reports: WaterQualityReport[], total: number }

POST /water-quality
  Body: { borehole_id: UUID, ph: number, tds_mg_l: number, turbidity: number, e_coli: number, nitrates?: number, iron?: number, tested_by: UUID, test_date: ISO8601, lab?: string, compliant: boolean }
  Response: { report: WaterQualityReport }

GET /water-quality/:id
  Response: { report: WaterQualityReport, borehole: Borehole, property: Property }

// ============================================================
// Invoices & Billing
// ============================================================

GET /invoices
  Query: ?property_id=UUID&status=paid|pending|overdue&limit=20&offset=0
  Response: { invoices: Invoice[], total: number, total_outstanding: number }

GET /invoices/:id
  Response: { invoice: Invoice, line_items: LineItem[], payments: Payment[] }

POST /invoices/:id/pay
  Body: { payment_method: 'card'|'eft'|'cash', amount: number, reference?: string }
  Response: { payment: Payment, invoice: Invoice }

// ============================================================
// Subscriptions (Maintenance Plans)
// ============================================================

GET /subscriptions
  Response: { subscriptions: Subscription[], plans: Plan[] }

POST /subscriptions
  Body: { plan_id: UUID, property_id: UUID, payment_method: string }
  Response: { subscription: Subscription, first_invoice: Invoice }

PATCH /subscriptions/:id
  Body: { status: 'active'|'paused'|'cancelled', plan_id?: UUID }
  Response: { subscription: Subscription }

// ============================================================
// Analytics (Admin)
// ============================================================

GET /analytics/dashboard
  Query: ?from=ISO8601&to=ISO8601
  Response: { jobs_completed: number, revenue: number, on_time_rate: number, avg_rating: number, technician_leaderboard: LeaderboardEntry[], service_breakdown: ServiceBreakdown[], daily_trend: TrendData[] }

GET /analytics/technicians/:id
  Query: ?from=ISO8601&to=ISO8601
  Response: { stats: TechnicianStats, jobs: Job[], revenue: number, ratings: RatingBreakdown }

GET /analytics/revenue
  Query: ?group_by=day|week|month&from=ISO8601&to=ISO8601
  Response: { revenue_data: RevenueDataPoint[], total: number, by_service_type: ServiceRevenue[] }

// ============================================================
// Notifications & Real-time
// ============================================================

WS /ws/notifications
  Events: job_assigned, status_update, emergency_alert, schedule_change

POST /notifications/push
  Body: { user_id: UUID, title: string, body: string, data?: object, priority: 'high'|'normal'|'low' }
  Response: { success: true, delivered: boolean }

// ============================================================
// Data Models (TypeScript interfaces)
// ============================================================

interface User {
  id: UUID;
  email: string;
  full_name: string;
  phone: string;
  role: 'admin' | 'dispatcher' | 'technician' | 'client';
  avatar_url?: string;
  created_at: ISO8601;
  updated_at: ISO8601;
}

interface Technician extends User {
  employee_id: string;
  base_location: GeoPoint;
  skills: string[];
  certifications: Certification[];
  current_status: 'available' | 'en_route' | 'on_site' | 'off_duty';
  current_job_id?: UUID;
  rating: number;
  jobs_completed: number;
  preferences: TechnicianPreferences;
}

interface Property {
  id: UUID;
  owner_id: UUID;
  name: string;
  address: string;
  suburb: string;
  city: string;
  type: 'residential' | 'commercial' | 'industrial' | 'agricultural';
  size_hectares?: number;
  estimated_value?: number;
  gps_coordinates?: GeoPoint;
  access_notes?: string;
  gate_code?: string;
  created_at: ISO8601;
}

interface Job {
  id: UUID;
  reference_number: string;
  property_id: UUID;
  technician_id?: UUID;
  type: 'installation' | 'repair' | 'maintenance' | 'water_test' | 'assessment' | 'emergency';
  urgency: 'emergency' | 'high' | 'medium' | 'low' | 'planning';
  status: 'pending' | 'dispatched' | 'en_route' | 'on_site' | 'completed' | 'cancelled';
  description: string;
  scheduled_date?: ISO8601;
  estimated_duration_minutes?: number;
  actual_start?: ISO8601;
  actual_end?: ISO8601;
  customer_rating?: number;
  technician_notes?: string;
  materials_cost?: number;
  labor_cost?: number;
  total_cost?: number;
  invoice_id?: UUID;
  created_at: ISO8601;
  updated_at: ISO8601;
}

interface WaterQualityReport {
  id: UUID;
  borehole_id: UUID;
  ph: number;
  tds_mg_l: number;
  turbidity: number;
  e_coli: number;
  nitrates?: number;
  iron?: number;
  tested_by: UUID;
  test_date: ISO8601;
  lab?: string;
  compliant: boolean;
  report_url?: string;
}

interface DispatchJob {
  job_id: UUID;
  priority_score: number;
  factors: {
    distance_km: number;
    skill_match: number;
    availability: number;
    urgency_weight: number;
  };
  recommended_technicians: UUID[];
}

// ============================================================
// Error Response Format
// ============================================================
// All errors return HTTP status code + JSON:
// { error: { code: string, message: string, details?: object }, request_id: string }
//
// Common Error Codes:
//   400 - bad_request, validation_error
//   401 - unauthorized, token_expired
//   403 - forbidden, insufficient_permissions
//   404 - not_found
//   409 - conflict, duplicate_entry
//   429 - rate_limited
//   500 - internal_error
// ============================================================
