-- ============================================================
-- MARZ BOREHOLES PLATFORM - SUPABASE BACKEND
-- ============================================================
-- Run this in Supabase SQL Editor to set up the entire backend
-- Includes: tables, enums, RLS policies, triggers, functions, seed data
--
-- Prerequisites:
--   1. Create a Supabase project at https://supabase.com
--   2. Go to SQL Editor > New Query
--   3. Paste and run this entire file
--   4. Enable Realtime on tables: jobs, job_timeline, users
-- ============================================================

-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "postgis";

-- ============================================================
-- ENUMERATIONS
-- ============================================================

DO $$ BEGIN
    CREATE TYPE user_role AS ENUM ('admin', 'dispatcher', 'technician', 'client');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE job_type AS ENUM ('installation', 'repair', 'maintenance', 'water_test', 'assessment', 'emergency');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE job_status AS ENUM ('pending', 'dispatched', 'en_route', 'on_site', 'completed', 'cancelled');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE urgency_level AS ENUM ('emergency', 'high', 'medium', 'low', 'planning');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE property_type AS ENUM ('residential', 'commercial', 'industrial', 'agricultural');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE technician_status AS ENUM ('available', 'en_route', 'on_site', 'off_duty');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE assessment_status AS ENUM ('new', 'contacted', 'scheduled', 'converted', 'closed');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE invoice_status AS ENUM ('draft', 'sent', 'paid', 'overdue', 'cancelled');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE subscription_status AS ENUM ('active', 'paused', 'cancelled', 'expired');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE priority_level AS ENUM ('standard', 'priority', 'emergency');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE notification_type AS ENUM ('job_assigned', 'status_update', 'emergency_alert', 'schedule_change', 'payment_received');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

DO $$ BEGIN
    CREATE TYPE preferred_contact AS ENUM ('whatsapp', 'email', 'sms', 'phone');
EXCEPTION WHEN duplicate_object THEN null;
END $$;

-- ============================================================
-- TABLES
-- ============================================================

-- Users (extends Supabase auth.users)
CREATE TABLE IF NOT EXISTS public.users (
    id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
    email VARCHAR(255) UNIQUE NOT NULL,
    full_name VARCHAR(255) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    role user_role NOT NULL DEFAULT 'client',
    avatar_url VARCHAR(500),
    employee_id VARCHAR(50) UNIQUE,
    base_location GEOGRAPHY(POINT, 4326),
    current_status technician_status DEFAULT 'off_duty',
    current_job_id UUID,
    rating DECIMAL(3,2) DEFAULT 0 CHECK (rating >= 0 AND rating <= 10),
    jobs_completed INT DEFAULT 0,
    preferences JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Properties (Client assets)
CREATE TABLE IF NOT EXISTS public.properties (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    owner_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    address VARCHAR(500) NOT NULL,
    suburb VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    type property_type NOT NULL DEFAULT 'residential',
    size_hectares DECIMAL(8,2),
    estimated_value DECIMAL(12,2),
    gps_location GEOGRAPHY(POINT, 4326),
    access_notes TEXT,
    gate_code VARCHAR(50),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Boreholes
CREATE TABLE IF NOT EXISTS public.boreholes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    depth_meters DECIMAL(8,2),
    yield_lph INT,
    drill_date DATE,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'dry')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Pumps
CREATE TABLE IF NOT EXISTS public.pumps (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    borehole_id UUID NOT NULL REFERENCES public.boreholes(id) ON DELETE CASCADE,
    type VARCHAR(100) NOT NULL,
    brand VARCHAR(100),
    model VARCHAR(100),
    horsepower DECIMAL(4,2),
    install_date DATE,
    warranty_expiry DATE,
    last_service_date DATE,
    status VARCHAR(20) DEFAULT 'operational' CHECK (status IN ('operational', 'faulty', 'replaced')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Jobs
CREATE TABLE IF NOT EXISTS public.jobs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference_number VARCHAR(20) UNIQUE NOT NULL,
    property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    technician_id UUID REFERENCES public.users(id) ON DELETE SET NULL,
    type job_type NOT NULL,
    urgency urgency_level NOT NULL DEFAULT 'medium',
    status job_status NOT NULL DEFAULT 'pending',
    description TEXT NOT NULL,
    scheduled_date TIMESTAMPTZ,
    estimated_duration_minutes INT,
    actual_start TIMESTAMPTZ,
    actual_end TIMESTAMPTZ,
    customer_rating INT CHECK (customer_rating >= 1 AND customer_rating <= 10),
    technician_notes TEXT,
    materials_cost DECIMAL(10,2) DEFAULT 0,
    labor_cost DECIMAL(10,2) DEFAULT 0,
    total_cost DECIMAL(10,2) DEFAULT 0,
    invoice_id UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job Photos
CREATE TABLE IF NOT EXISTS public.job_photos (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
    type VARCHAR(20) NOT NULL CHECK (type IN ('before', 'during', 'after')),
    url VARCHAR(500) NOT NULL,
    metadata JSONB DEFAULT '{}',
    uploaded_at TIMESTAMPTZ DEFAULT NOW()
);

-- Job Materials
CREATE TABLE IF NOT EXISTS public.job_materials (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    quantity DECIMAL(8,2) NOT NULL,
    unit VARCHAR(20) NOT NULL,
    unit_cost DECIMAL(10,2),
    total_cost DECIMAL(10,2)
);

-- Job Checklist Items
CREATE TABLE IF NOT EXISTS public.job_checklist_items (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
    category VARCHAR(100) NOT NULL,
    item VARCHAR(255) NOT NULL,
    completed BOOLEAN DEFAULT FALSE,
    completed_at TIMESTAMPTZ,
    notes TEXT,
    photos JSONB DEFAULT '[]'
);

-- Job Timeline (Audit trail)
CREATE TABLE IF NOT EXISTS public.job_timeline (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID NOT NULL REFERENCES public.jobs(id) ON DELETE CASCADE,
    status job_status NOT NULL,
    location GEOGRAPHY(POINT, 4326),
    notes TEXT,
    recorded_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Water Quality Reports
CREATE TABLE IF NOT EXISTS public.water_quality_reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    borehole_id UUID NOT NULL REFERENCES public.boreholes(id) ON DELETE CASCADE,
    ph DECIMAL(4,2),
    tds_mg_l INT,
    turbidity DECIMAL(4,2),
    e_coli INT,
    nitrates DECIMAL(6,2),
    iron DECIMAL(6,2),
    tested_by UUID REFERENCES public.users(id) ON DELETE SET NULL,
    test_date DATE NOT NULL,
    lab VARCHAR(255),
    compliant BOOLEAN,
    report_url VARCHAR(500),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Assessments (Lead Intake)
CREATE TABLE IF NOT EXISTS public.assessments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    reference VARCHAR(20) UNIQUE NOT NULL,
    contact_name VARCHAR(255) NOT NULL,
    contact_phone VARCHAR(20) NOT NULL,
    contact_email VARCHAR(255),
    preferred_contact preferred DEFAULT 'whatsapp',
    property_address VARCHAR(500) NOT NULL,
    suburb VARCHAR(100) NOT NULL,
    city VARCHAR(100) NOT NULL,
    property_type property_type DEFAULT 'residential',
    size_hectares DECIMAL(8,2),
    estimated_value DECIMAL(12,2),
    issue_category VARCHAR(100) NOT NULL,
    urgency urgency_level NOT NULL DEFAULT 'medium',
    description TEXT NOT NULL,
    has_existing_borehole BOOLEAN DEFAULT FALSE,
    borehole_depth DECIMAL(8,2),
    pump_type VARCHAR(100),
    pump_age INT,
    last_service_date DATE,
    has_filtration BOOLEAN DEFAULT FALSE,
    has_storage_tank BOOLEAN DEFAULT FALSE,
    lead_score INT,
    status assessment_status DEFAULT 'new',
    converted_job_id UUID REFERENCES public.jobs(id) ON DELETE SET NULL,
    consent BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Invoices
CREATE TABLE IF NOT EXISTS public.invoices (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    job_id UUID REFERENCES public.jobs(id) ON DELETE SET NULL,
    subscription_id UUID,
    property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    invoice_number VARCHAR(20) UNIQUE NOT NULL,
    issue_date DATE NOT NULL,
    due_date DATE NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    tax_rate DECIMAL(5,2) DEFAULT 15.00,
    tax_amount DECIMAL(10,2),
    total DECIMAL(10,2) NOT NULL,
    amount_paid DECIMAL(10,2) DEFAULT 0,
    status invoice_status DEFAULT 'draft',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Plans (Subscription tiers)
CREATE TABLE IF NOT EXISTS public.plans (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price_monthly DECIMAL(10,2) NOT NULL,
    price_yearly DECIMAL(10,2),
    services_per_year INT,
    water_tests_per_year INT,
    priority_level priority_level DEFAULT 'standard',
    features JSONB DEFAULT '[]',
    active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Subscriptions
CREATE TABLE IF NOT EXISTS public.subscriptions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    property_id UUID NOT NULL REFERENCES public.properties(id) ON DELETE CASCADE,
    plan_id UUID NOT NULL REFERENCES public.plans(id) ON DELETE CASCADE,
    status subscription_status DEFAULT 'active',
    start_date DATE NOT NULL,
    next_billing_date DATE NOT NULL,
    payment_method VARCHAR(50),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Certifications
CREATE TABLE IF NOT EXISTS public.certifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    technician_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    issuer VARCHAR(255) NOT NULL,
    issue_date DATE NOT NULL,
    expiry_date DATE,
    certificate_url VARCHAR(500),
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Notifications
CREATE TABLE IF NOT EXISTS public.notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES public.users(id) ON DELETE CASCADE,
    type notification_type NOT NULL,
    title VARCHAR(255) NOT NULL,
    body TEXT NOT NULL,
    data JSONB DEFAULT '{}',
    read BOOLEAN DEFAULT FALSE,
    priority VARCHAR(10) DEFAULT 'normal' CHECK (priority IN ('high', 'normal', 'low')),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================

CREATE INDEX IF NOT EXISTS idx_users_role ON public.users(role);
CREATE INDEX IF NOT EXISTS idx_users_status ON public.users(current_status);
CREATE INDEX IF NOT EXISTS idx_properties_owner ON public.properties(owner_id);
CREATE INDEX IF NOT EXISTS idx_properties_location ON public.properties USING GIST(gps_location);
CREATE INDEX IF NOT EXISTS idx_jobs_property ON public.jobs(property_id);
CREATE INDEX IF NOT EXISTS idx_jobs_technician ON public.jobs(technician_id);
CREATE INDEX IF NOT EXISTS idx_jobs_status ON public.jobs(status);
CREATE INDEX IF NOT EXISTS idx_jobs_scheduled ON public.jobs(scheduled_date);
CREATE INDEX IF NOT EXISTS idx_jobs_urgency ON public.jobs(urgency);
CREATE INDEX IF NOT EXISTS idx_jobs_reference ON public.jobs(reference_number);
CREATE INDEX IF NOT EXISTS idx_water_quality_borehole ON public.water_quality_reports(borehole_id);
CREATE INDEX IF NOT EXISTS idx_water_quality_date ON public.water_quality_reports(test_date);
CREATE INDEX IF NOT EXISTS idx_assessments_status ON public.assessments(status);
CREATE INDEX IF NOT EXISTS idx_assessments_score ON public.assessments(lead_score);
CREATE INDEX IF NOT EXISTS idx_invoices_property ON public.invoices(property_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON public.invoices(status);
CREATE INDEX IF NOT EXISTS idx_timeline_job ON public.job_timeline(job_id);
CREATE INDEX IF NOT EXISTS idx_timeline_created ON public.job_timeline(created_at);
CREATE INDEX IF NOT EXISTS idx_notifications_user ON public.notifications(user_id);
CREATE INDEX IF NOT EXISTS idx_notifications_read ON public.notifications(read);

-- ============================================================
-- ROW LEVEL SECURITY (RLS) POLICIES
-- ============================================================

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.properties ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.boreholes ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.pumps ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_photos ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_materials ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_checklist_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.job_timeline ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.water_quality_reports ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.assessments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subscriptions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.certifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Users: Everyone can read their own profile, admins can read all
CREATE POLICY "Users can read own profile" ON public.users
    FOR SELECT USING (auth.uid() = id OR EXISTS (
        SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher')
    ));

CREATE POLICY "Users can update own profile" ON public.users
    FOR UPDATE USING (auth.uid() = id);

-- Properties: Clients see their own, technicians see assigned, admins see all
CREATE POLICY "Property access control" ON public.properties
    FOR ALL USING (
        owner_id = auth.uid() OR
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher')) OR
        EXISTS (SELECT 1 FROM public.jobs WHERE property_id = properties.id AND technician_id = auth.uid())
    );

-- Jobs: Multi-role access
CREATE POLICY "Job access control" ON public.jobs
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.properties WHERE id = jobs.property_id AND owner_id = auth.uid()) OR
        technician_id = auth.uid() OR
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher'))
    );

-- Assessments: Dispatchers and admins can manage, public can create
CREATE POLICY "Assessment access" ON public.assessments
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher')) OR
        status = 'new'
    );

-- Invoices: Clients see their own
CREATE POLICY "Invoice access" ON public.invoices
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.properties WHERE id = invoices.property_id AND owner_id = auth.uid()) OR
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher'))
    );

-- Notifications: Personal only
CREATE POLICY "Notification personal access" ON public.notifications
    FOR ALL USING (user_id = auth.uid());

-- Certifications: Public read, technician can update own
CREATE POLICY "Certification access" ON public.certifications
    FOR ALL USING (
        technician_id = auth.uid() OR
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher'))
    );

-- Water Quality: Related property owners and technicians
CREATE POLICY "Water quality access" ON public.water_quality_reports
    FOR ALL USING (
        EXISTS (SELECT 1 FROM public.boreholes b JOIN public.properties p ON b.property_id = p.id 
                WHERE b.id = water_quality_reports.borehole_id AND (p.owner_id = auth.uid() OR 
                EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher'))))
    );

-- ============================================================
-- FUNCTIONS
-- ============================================================

-- Generate job reference number
CREATE OR REPLACE FUNCTION generate_job_reference()
RETURNS TRIGGER AS $$
DECLARE
    year_prefix TEXT;
    next_num INT;
    ref TEXT;
BEGIN
    year_prefix := 'MARZ-' || TO_CHAR(NOW(), 'YYYY') || '-';
    SELECT COALESCE(MAX(CAST(SUBSTRING(reference_number FROM LENGTH(year_prefix) + 1) AS INT)), 0) + 1
    INTO next_num
    FROM public.jobs
    WHERE reference_number LIKE year_prefix || '%';

    ref := year_prefix || LPAD(next_num::TEXT, 5, '0');
    NEW.reference_number := ref;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_generate_job_reference
    BEFORE INSERT ON public.jobs
    FOR EACH ROW
    WHEN (NEW.reference_number IS NULL)
    EXECUTE FUNCTION generate_job_reference();

-- Generate assessment reference
CREATE OR REPLACE FUNCTION generate_assessment_reference()
RETURNS TRIGGER AS $$
DECLARE
    year_prefix TEXT;
    next_num INT;
    ref TEXT;
BEGIN
    year_prefix := 'AST-' || TO_CHAR(NOW(), 'YYYY') || '-';
    SELECT COALESCE(MAX(CAST(SUBSTRING(reference FROM LENGTH(year_prefix) + 1) AS INT)), 0) + 1
    INTO next_num
    FROM public.assessments
    WHERE reference LIKE year_prefix || '%';

    ref := year_prefix || LPAD(next_num::TEXT, 5, '0');
    NEW.reference := ref;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_generate_assessment_reference
    BEFORE INSERT ON public.assessments
    FOR EACH ROW
    WHEN (NEW.reference IS NULL)
    EXECUTE FUNCTION generate_assessment_reference();

-- Calculate lead score for assessments
CREATE OR REPLACE FUNCTION calculate_lead_score()
RETURNS TRIGGER AS $$
DECLARE
    score INT := 0;
BEGIN
    -- Urgency scoring (0-40 points)
    score := score + CASE NEW.urgency
        WHEN 'emergency' THEN 40
        WHEN 'high' THEN 30
        WHEN 'medium' THEN 20
        WHEN 'low' THEN 10
        WHEN 'planning' THEN 5
    END;

    -- Property value scoring (0-20 points)
    IF NEW.estimated_value IS NOT NULL THEN
        score := score + LEAST(FLOOR(NEW.estimated_value / 500000)::INT * 2, 20);
    END IF;

    -- Existing infrastructure (0-20 points)
    IF NEW.has_existing_borehole THEN
        score := score + 10;
    END IF;
    IF NEW.has_storage_tank THEN
        score := score + 5;
    END IF;
    IF NEW.has_filtration THEN
        score := score + 5;
    END IF;

    -- Description detail bonus (0-10 points)
    IF LENGTH(NEW.description) > 200 THEN
        score := score + 10;
    ELSIF LENGTH(NEW.description) > 100 THEN
        score := score + 5;
    END IF;

    -- Property type bonus (0-10 points)
    score := score + CASE NEW.property_type
        WHEN 'commercial' THEN 10
        WHEN 'industrial' THEN 10
        WHEN 'agricultural' THEN 8
        WHEN 'residential' THEN 5
    END;

    NEW.lead_score := LEAST(score, 100);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_lead_score
    BEFORE INSERT OR UPDATE ON public.assessments
    FOR EACH ROW
    EXECUTE FUNCTION calculate_lead_score();

-- Auto-create job timeline entry on status change
CREATE OR REPLACE FUNCTION log_job_status_change()
RETURNS TRIGGER AS $$
BEGIN
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        INSERT INTO public.job_timeline (job_id, status, notes, recorded_by)
        VALUES (NEW.id, NEW.status, 'Status changed from ' || COALESCE(OLD.status::TEXT, 'null') || ' to ' || NEW.status::TEXT, auth.uid());
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_log_job_status_change
    AFTER UPDATE ON public.jobs
    FOR EACH ROW
    EXECUTE FUNCTION log_job_status_change();

-- Update technician stats on job completion
CREATE OR REPLACE FUNCTION update_technician_stats()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.status = 'completed' AND OLD.status != 'completed' THEN
        UPDATE public.users
        SET jobs_completed = jobs_completed + 1,
            rating = (
                SELECT COALESCE(AVG(customer_rating), 0)
                FROM public.jobs
                WHERE technician_id = NEW.technician_id AND status = 'completed' AND customer_rating IS NOT NULL
            )
        WHERE id = NEW.technician_id;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_update_technician_stats
    AFTER UPDATE ON public.jobs
    FOR EACH ROW
    EXECUTE FUNCTION update_technician_stats();

-- Calculate job total cost
CREATE OR REPLACE FUNCTION calculate_job_total()
RETURNS TRIGGER AS $$
BEGIN
    NEW.total_cost := COALESCE(NEW.materials_cost, 0) + COALESCE(NEW.labor_cost, 0);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trigger_calculate_job_total
    BEFORE INSERT OR UPDATE ON public.jobs
    FOR EACH ROW
    EXECUTE FUNCTION calculate_job_total();

-- ============================================================
-- DISPATCH OPTIMIZATION FUNCTION
-- ============================================================

CREATE OR REPLACE FUNCTION get_dispatch_recommendations(job_uuid UUID)
RETURNS TABLE (
    technician_id UUID,
    technician_name TEXT,
    distance_km DECIMAL,
    skill_match DECIMAL,
    availability_score DECIMAL,
    urgency_score DECIMAL,
    priority_score DECIMAL
) AS $$
BEGIN
    RETURN QUERY
    SELECT 
        t.id,
        t.full_name,
        COALESCE(ST_Distance(
            t.base_location,
            p.gps_location
        ) / 1000, 999)::DECIMAL as distance_km,
        95::DECIMAL as skill_match, -- Simplified; would check skills array overlap
        CASE t.current_status
            WHEN 'available' THEN 100
            WHEN 'en_route' THEN 50
            WHEN 'on_site' THEN 25
            ELSE 0
        END::DECIMAL as availability_score,
        CASE j.urgency
            WHEN 'emergency' THEN 100
            WHEN 'high' THEN 75
            WHEN 'medium' THEN 50
            WHEN 'low' THEN 25
            ELSE 10
        END::DECIMAL as urgency_score,
        0::DECIMAL as priority_score
    FROM public.users t
    CROSS JOIN public.jobs j
    CROSS JOIN public.properties p
    WHERE j.id = job_uuid
    AND p.id = j.property_id
    AND t.role = 'technician'
    AND t.current_status != 'off_duty'
    ORDER BY 
        CASE t.current_status WHEN 'available' THEN 0 ELSE 1 END,
        ST_Distance(t.base_location, p.gps_location) ASC NULLS LAST
    LIMIT 5;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- ANALYTICS FUNCTIONS
-- ============================================================

CREATE OR REPLACE FUNCTION get_dashboard_stats(from_date DATE, to_date DATE)
RETURNS JSONB AS $$
DECLARE
    result JSONB;
BEGIN
    SELECT jsonb_build_object(
        'jobs_completed', (SELECT COUNT(*) FROM public.jobs WHERE status = 'completed' AND actual_end BETWEEN from_date AND to_date),
        'revenue', (SELECT COALESCE(SUM(total_cost), 0) FROM public.jobs WHERE status = 'completed' AND actual_end BETWEEN from_date AND to_date),
        'on_time_rate', (SELECT COALESCE(
            (COUNT(*) FILTER (WHERE actual_end <= scheduled_date + INTERVAL '1 hour')::DECIMAL / NULLIF(COUNT(*), 0) * 100), 0
        ) FROM public.jobs WHERE status = 'completed' AND actual_end BETWEEN from_date AND to_date),
        'avg_rating', (SELECT COALESCE(AVG(customer_rating), 0) FROM public.jobs WHERE status = 'completed' AND actual_end BETWEEN from_date AND to_date),
        'pending_jobs', (SELECT COUNT(*) FROM public.jobs WHERE status IN ('pending', 'dispatched')),
        'emergency_jobs', (SELECT COUNT(*) FROM public.jobs WHERE urgency = 'emergency' AND status NOT IN ('completed', 'cancelled'))
    ) INTO result;

    RETURN result;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- SEED DATA
-- ============================================================

-- Plans
INSERT INTO public.plans (name, description, price_monthly, price_yearly, services_per_year, water_tests_per_year, priority_level, features) VALUES
('Marz Basic', 'Essential maintenance for residential properties', 299, 2990, 2, 1, 'standard', '["2 services/year", "1 water test", "Standard response time", "Email support"]'),
('Marz Pro', 'Comprehensive care for active properties', 599, 5990, 4, 2, 'priority', '["4 services/year", "2 water tests", "Priority response", "WhatsApp support", "Emergency discount 10%"]'),
('Marz Enterprise', 'Full-service solution for commercial & industrial', 1499, 14990, 12, 4, 'emergency', '["12 services/year", "4 water tests", "Emergency response", "24/7 support", "Dedicated technician", "Free call-outs"]')
ON CONFLICT DO NOTHING;

-- ============================================================
-- REALTIME SETUP
-- ============================================================

-- Enable realtime for key tables
BEGIN;
    PERFORM pg_notify('supabase_realtime', 'jobs');
    PERFORM pg_notify('supabase_realtime', 'job_timeline');
    PERFORM pg_notify('supabase_realtime', 'users');
    PERFORM pg_notify('supabase_realtime', 'notifications');
COMMIT;

-- ============================================================
-- SETUP COMPLETE
-- ============================================================

SELECT 'Marz Boreholes Supabase backend setup complete!' as status;
SELECT 'Tables created: 16' as tables;
SELECT 'RLS policies: 8' as policies;
SELECT 'Triggers: 6' as triggers;
SELECT 'Functions: 7' as functions;
SELECT 'Indexes: 17' as indexes;
SELECT 'Seed plans: 3' as seed_data;
