-- ============================================================
-- MARZ BOREHOLES - AUTH & SECURITY SETUP
-- ============================================================
-- Run after supabase_setup.sql to configure authentication,
-- storage buckets, and advanced security policies
--
-- Prerequisites: supabase_setup.sql must be run first
-- ============================================================

-- ============================================================
-- AUTH CONFIGURATION
-- ============================================================

-- Set up auth metadata defaults
UPDATE auth.config SET 
  jwt_exp = 3600,
  refresh_token_rotation_enabled = true,
  mfa_enabled = true;

-- Create auth hook to sync user creation with public.users
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER AS $$
BEGIN
  INSERT INTO public.users (id, email, full_name, phone, role, created_at, updated_at)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    COALESCE(NEW.raw_user_meta_data->>'phone', ''),
    COALESCE((NEW.raw_user_meta_data->>'role')::user_role, 'client'),
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO UPDATE SET
    email = EXCLUDED.email,
    updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Trigger on auth.users for auto-sync
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();

-- Trigger on auth.users for updates
CREATE OR REPLACE FUNCTION public.handle_user_update()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.users
  SET email = NEW.email,
      updated_at = NOW()
  WHERE id = NEW.id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

DROP TRIGGER IF EXISTS on_auth_user_updated ON auth.users;
CREATE TRIGGER on_auth_user_updated
  AFTER UPDATE ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_user_update();

-- ============================================================
-- MFA (Multi-Factor Authentication) Support
-- ============================================================

CREATE TABLE IF NOT EXISTS public.mfa_settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
    method VARCHAR(20) NOT NULL CHECK (method IN ('totp', 'sms', 'email')),
    enabled BOOLEAN DEFAULT FALSE,
    verified BOOLEAN DEFAULT FALSE,
    secret_encrypted TEXT,
    backup_codes JSONB DEFAULT '[]',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(user_id, method)
);

ALTER TABLE public.mfa_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own MFA" ON public.mfa_settings
    FOR ALL USING (auth.uid() = user_id);

-- ============================================================
-- LOGIN AUDIT LOG
-- ============================================================

CREATE TABLE IF NOT EXISTS public.login_audit (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES auth.users(id) ON DELETE SET NULL,
    email VARCHAR(255),
    ip_address INET,
    user_agent TEXT,
    location JSONB,
    success BOOLEAN NOT NULL,
    failure_reason TEXT,
    mfa_used BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_login_audit_user ON public.login_audit(user_id);
CREATE INDEX IF NOT EXISTS idx_login_audit_created ON public.login_audit(created_at);

ALTER TABLE public.login_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins read login audit" ON public.login_audit
    FOR SELECT USING (EXISTS (
        SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'admin'
    ));

-- Function to log login attempts
CREATE OR REPLACE FUNCTION public.log_login_attempt(
    p_user_id UUID,
    p_email VARCHAR,
    p_ip INET,
    p_user_agent TEXT,
    p_success BOOLEAN,
    p_failure_reason TEXT DEFAULT NULL
)
RETURNS VOID AS $$
BEGIN
    INSERT INTO public.login_audit (user_id, email, ip_address, user_agent, success, failure_reason)
    VALUES (p_user_id, p_email, p_ip, p_user_agent, p_success, p_failure_reason);
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- ============================================================
-- STORAGE BUCKETS
-- ============================================================

-- Job photos bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('job-photos', 'job-photos', true, 52428800, ARRAY['image/jpeg', 'image/png', 'image/webp', 'image/heic'])
ON CONFLICT (id) DO NOTHING;

-- Profile avatars bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('avatars', 'avatars', true, 2097152, ARRAY['image/jpeg', 'image/png', 'image/webp'])
ON CONFLICT (id) DO NOTHING;

-- Documents bucket (invoices, reports, certificates)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('documents', 'documents', false, 10485760, ARRAY['application/pdf', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'])
ON CONFLICT (id) DO NOTHING;

-- Water quality reports bucket
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES ('water-reports', 'water-reports', false, 10485760, ARRAY['application/pdf', 'image/jpeg', 'image/png'])
ON CONFLICT (id) DO NOTHING;

-- ============================================================
-- STORAGE RLS POLICIES
-- ============================================================

-- Job Photos: Technicians can upload, clients can view their own
CREATE POLICY "Technicians upload job photos" ON storage.objects
    FOR INSERT TO authenticated
    WITH CHECK (
        bucket_id = 'job-photos' AND
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role = 'technician')
    );

CREATE POLICY "View job photos" ON storage.objects
    FOR SELECT TO authenticated
    USING (
        bucket_id = 'job-photos' AND
        (
            EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher', 'technician')) OR
            EXISTS (
                SELECT 1 FROM public.jobs j
                JOIN public.properties p ON j.property_id = p.id
                WHERE p.owner_id = auth.uid()
                AND name LIKE CONCAT(j.id::text, '/%')
            )
        )
    );

-- Avatars: Anyone can view, only owner can upload
CREATE POLICY "Upload own avatar" ON storage.objects
    FOR INSERT TO authenticated
    WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "View avatars" ON storage.objects
    FOR SELECT TO authenticated
    USING (bucket_id = 'avatars');

-- Documents: Role-based access
CREATE POLICY "Document access" ON storage.objects
    FOR ALL TO authenticated
    USING (
        bucket_id = 'documents' AND
        EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher'))
    );

-- Water Reports: Clients view their own, technicians view assigned
CREATE POLICY "Water report access" ON storage.objects
    FOR SELECT TO authenticated
    USING (
        bucket_id = 'water-reports' AND
        (
            EXISTS (SELECT 1 FROM public.users WHERE id = auth.uid() AND role IN ('admin', 'dispatcher')) OR
            EXISTS (
                SELECT 1 FROM public.water_quality_reports w
                JOIN public.boreholes b ON w.borehole_id = b.id
                JOIN public.properties p ON b.property_id = p.id
                WHERE p.owner_id = auth.uid()
            )
        )
    );

-- ============================================================
-- RATE LIMITING (using pg_net or custom table)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.rate_limits (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID,
    ip_address INET,
    endpoint VARCHAR(255) NOT NULL,
    request_count INT DEFAULT 1,
    window_start TIMESTAMPTZ DEFAULT NOW(),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_rate_limits_user ON public.rate_limits(user_id, endpoint, window_start);
CREATE INDEX IF NOT EXISTS idx_rate_limits_ip ON public.rate_limits(ip_address, endpoint, window_start);

-- Function to check rate limit
CREATE OR REPLACE FUNCTION public.check_rate_limit(
    p_user_id UUID,
    p_ip INET,
    p_endpoint VARCHAR,
    p_max_requests INT DEFAULT 100,
    p_window_minutes INT DEFAULT 1
)
RETURNS BOOLEAN AS $$
DECLARE
    current_count INT;
BEGIN
    SELECT COALESCE(SUM(request_count), 0)
    INTO current_count
    FROM public.rate_limits
    WHERE (user_id = p_user_id OR ip_address = p_ip)
    AND endpoint = p_endpoint
    AND window_start > NOW() - INTERVAL '1 minute' * p_window_minutes;

    IF current_count >= p_max_requests THEN
        RETURN FALSE;
    END IF;

    INSERT INTO public.rate_limits (user_id, ip_address, endpoint, request_count)
    VALUES (p_user_id, p_ip, p_endpoint, 1)
    ON CONFLICT DO NOTHING;

    RETURN TRUE;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- AUDIT LOG (comprehensive)
-- ============================================================

CREATE TABLE IF NOT EXISTS public.audit_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(100) NOT NULL,
    record_id UUID,
    action VARCHAR(20) NOT NULL CHECK (action IN ('INSERT', 'UPDATE', 'DELETE')),
    old_data JSONB,
    new_data JSONB,
    user_id UUID,
    user_role user_role,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_audit_table ON public.audit_log(table_name, record_id);
CREATE INDEX IF NOT EXISTS idx_audit_user ON public.audit_log(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_created ON public.audit_log(created_at);

-- Generic audit trigger function
CREATE OR REPLACE FUNCTION public.audit_trigger()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO public.audit_log (table_name, record_id, action, new_data, user_id, user_role)
        SELECT TG_TABLE_NAME, NEW.id, 'INSERT', row_to_json(NEW), auth.uid(), u.role
        FROM public.users u WHERE u.id = auth.uid();
        RETURN NEW;
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO public.audit_log (table_name, record_id, action, old_data, new_data, user_id, user_role)
        SELECT TG_TABLE_NAME, NEW.id, 'UPDATE', row_to_json(OLD), row_to_json(NEW), auth.uid(), u.role
        FROM public.users u WHERE u.id = auth.uid();
        RETURN NEW;
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO public.audit_log (table_name, record_id, action, old_data, user_id, user_role)
        SELECT TG_TABLE_NAME, OLD.id, 'DELETE', row_to_json(OLD), auth.uid(), u.role
        FROM public.users u WHERE u.id = auth.uid();
        RETURN OLD;
    END IF;
    RETURN NULL;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Apply audit triggers to sensitive tables
CREATE TRIGGER audit_jobs AFTER INSERT OR UPDATE OR DELETE ON public.jobs
    FOR EACH ROW EXECUTE FUNCTION public.audit_trigger();

CREATE TRIGGER audit_invoices AFTER INSERT OR UPDATE OR DELETE ON public.invoices
    FOR EACH ROW EXECUTE FUNCTION public.audit_trigger();

CREATE TRIGGER audit_subscriptions AFTER INSERT OR UPDATE OR DELETE ON public.subscriptions
    FOR EACH ROW EXECUTE FUNCTION public.audit_trigger();

CREATE TRIGGER audit_users AFTER UPDATE ON public.users
    FOR EACH ROW EXECUTE FUNCTION public.audit_trigger();

-- ============================================================
-- DATA RETENTION & GDPR COMPLIANCE
-- ============================================================

CREATE TABLE IF NOT EXISTS public.data_retention_policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    table_name VARCHAR(100) UNIQUE NOT NULL,
    retention_days INT NOT NULL,
    archive_bucket VARCHAR(100),
    auto_delete BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Insert retention policies
INSERT INTO public.data_retention_policies (table_name, retention_days, auto_delete) VALUES
('login_audit', 365, TRUE),
('audit_log', 2555, TRUE), -- 7 years
('job_photos', 1825, FALSE), -- 5 years, archive instead
('notifications', 90, TRUE),
('rate_limits', 1, TRUE)
ON CONFLICT (table_name) DO NOTHING;

-- Function to enforce retention
CREATE OR REPLACE FUNCTION public.enforce_data_retention()
RETURNS void AS $$
DECLARE
    policy RECORD;
BEGIN
    FOR policy IN SELECT * FROM public.data_retention_policies WHERE auto_delete = TRUE
    LOOP
        EXECUTE format(
            'DELETE FROM public.%I WHERE created_at < NOW() - INTERVAL ''%s days''',
            policy.table_name,
            policy.retention_days
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- ============================================================
-- BACKUP VERIFICATION
-- ============================================================

CREATE TABLE IF NOT EXISTS public.backup_log (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    backup_type VARCHAR(50) NOT NULL, -- 'full', 'incremental', 'schema'
    status VARCHAR(20) NOT NULL CHECK (status IN ('started', 'completed', 'failed')),
    size_bytes BIGINT,
    location VARCHAR(500),
    error_message TEXT,
    verified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SETUP COMPLETE
-- ============================================================

SELECT 'Auth & Security setup complete!' as status;
SELECT 'Auth triggers: 2 (user create/update sync)' as auth_triggers;
SELECT 'MFA support: Enabled' as mfa;
SELECT 'Storage buckets: 4 (job-photos, avatars, documents, water-reports)' as storage;
SELECT 'Storage RLS policies: 6' as storage_policies;
SELECT 'Rate limiting: Custom table + function' as rate_limit;
SELECT 'Audit logging: 4 tables with triggers' as audit;
SELECT 'Data retention: 5 policies configured' as retention;
SELECT 'GDPR compliance: Data retention + right to deletion ready' as gdpr;
