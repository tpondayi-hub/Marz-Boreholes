# Marz Boreholes - Database Schema

## Entity Relationship Diagram

```mermaid
erDiagram
    USERS ||--o{ PROPERTIES : owns
    USERS ||--o{ JOBS : assigned_to
    USERS ||--o{ CERTIFICATIONS : has
    USERS ||--o{ NOTIFICATIONS : receives

    PROPERTIES ||--o{ BOREHOLES : contains
    PROPERTIES ||--o{ JOBS : has
    PROPERTIES ||--o{ SUBSCRIPTIONS : subscribed_to

    BOREHOLES ||--o{ WATER_QUALITY_REPORTS : tested
    BOREHOLES ||--o{ PUMPS : has

    JOBS ||--o{ JOB_PHOTOS : documents
    JOBS ||--o{ JOB_MATERIALS : uses
    JOBS ||--o{ JOB_CHECKLIST_ITEMS : tracks
    JOBS ||--o{ JOB_TIMELINE : logs
    JOBS ||--|| INVOICES : generates

    USERS ||--o{ ASSESSMENTS : submits
    ASSESSMENTS ||--o{ JOBS : converts_to

    SUBSCRIPTIONS ||--o{ INVOICES : billed
    PLANS ||--o{ SUBSCRIPTIONS : defines
```

## Core Tables

### users
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| email | VARCHAR(255) | UNIQUE, NOT NULL |
| password_hash | VARCHAR(255) | NOT NULL |
| full_name | VARCHAR(255) | NOT NULL |
| phone | VARCHAR(20) | NOT NULL |
| role | ENUM | admin, dispatcher, technician, client |
| avatar_url | VARCHAR(500) | |
| employee_id | VARCHAR(50) | UNIQUE (technicians) |
| base_location_lat | DECIMAL(10,8) | |
| base_location_lng | DECIMAL(11,8) | |
| current_status | ENUM | available, en_route, on_site, off_duty |
| current_job_id | UUID | FK -> jobs |
| rating | DECIMAL(3,2) | DEFAULT 0 |
| jobs_completed | INT | DEFAULT 0 |
| preferences | JSONB | |
| created_at | TIMESTAMP | DEFAULT NOW() |
| updated_at | TIMESTAMP | DEFAULT NOW() |

### properties
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| owner_id | UUID | FK -> users, NOT NULL |
| name | VARCHAR(255) | NOT NULL |
| address | VARCHAR(500) | NOT NULL |
| suburb | VARCHAR(100) | NOT NULL |
| city | VARCHAR(100) | NOT NULL |
| type | ENUM | residential, commercial, industrial, agricultural |
| size_hectares | DECIMAL(8,2) | |
| estimated_value | DECIMAL(12,2) | |
| gps_lat | DECIMAL(10,8) | |
| gps_lng | DECIMAL(11,8) | |
| access_notes | TEXT | |
| gate_code | VARCHAR(50) | |
| created_at | TIMESTAMP | DEFAULT NOW() |

### boreholes
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| property_id | UUID | FK -> properties, NOT NULL |
| depth_meters | DECIMAL(8,2) | |
| yield_lph | INT | |
| drill_date | DATE | |
| status | ENUM | active, inactive, dry |
| created_at | TIMESTAMP | DEFAULT NOW() |

### pumps
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| borehole_id | UUID | FK -> boreholes, NOT NULL |
| type | VARCHAR(100) | NOT NULL |
| brand | VARCHAR(100) | |
| model | VARCHAR(100) | |
| horsepower | DECIMAL(4,2) | |
| install_date | DATE | |
| warranty_expiry | DATE | |
| last_service_date | DATE | |
| status | ENUM | operational, faulty, replaced |

### jobs
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| reference_number | VARCHAR(20) | UNIQUE, NOT NULL |
| property_id | UUID | FK -> properties, NOT NULL |
| technician_id | UUID | FK -> users |
| type | ENUM | installation, repair, maintenance, water_test, assessment, emergency |
| urgency | ENUM | emergency, high, medium, low, planning |
| status | ENUM | pending, dispatched, en_route, on_site, completed, cancelled |
| description | TEXT | NOT NULL |
| scheduled_date | TIMESTAMP | |
| estimated_duration_minutes | INT | |
| actual_start | TIMESTAMP | |
| actual_end | TIMESTAMP | |
| customer_rating | INT | CHECK (1-10) |
| technician_notes | TEXT | |
| materials_cost | DECIMAL(10,2) | DEFAULT 0 |
| labor_cost | DECIMAL(10,2) | DEFAULT 0 |
| total_cost | DECIMAL(10,2) | DEFAULT 0 |
| invoice_id | UUID | FK -> invoices |
| created_at | TIMESTAMP | DEFAULT NOW() |
| updated_at | TIMESTAMP | DEFAULT NOW() |

### job_photos
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| job_id | UUID | FK -> jobs, NOT NULL |
| type | ENUM | before, during, after |
| url | VARCHAR(500) | NOT NULL |
| metadata | JSONB | |
| uploaded_at | TIMESTAMP | DEFAULT NOW() |

### job_materials
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| job_id | UUID | FK -> jobs, NOT NULL |
| name | VARCHAR(255) | NOT NULL |
| quantity | DECIMAL(8,2) | NOT NULL |
| unit | VARCHAR(20) | NOT NULL |
| unit_cost | DECIMAL(10,2) | |
| total_cost | DECIMAL(10,2) | |

### job_checklist_items
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| job_id | UUID | FK -> jobs, NOT NULL |
| category | VARCHAR(100) | NOT NULL |
| item | VARCHAR(255) | NOT NULL |
| completed | BOOLEAN | DEFAULT FALSE |
| completed_at | TIMESTAMP | |
| notes | TEXT | |
| photos | JSONB | |

### job_timeline
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| job_id | UUID | FK -> jobs, NOT NULL |
| status | ENUM | NOT NULL |
| location_lat | DECIMAL(10,8) | |
| location_lng | DECIMAL(11,8) | |
| notes | TEXT | |
| recorded_by | UUID | FK -> users |
| created_at | TIMESTAMP | DEFAULT NOW() |

### water_quality_reports
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| borehole_id | UUID | FK -> boreholes, NOT NULL |
| ph | DECIMAL(4,2) | |
| tds_mg_l | INT | |
| turbidity | DECIMAL(4,2) | |
| e_coli | INT | |
| nitrates | DECIMAL(6,2) | |
| iron | DECIMAL(6,2) | |
| tested_by | UUID | FK -> users |
| test_date | DATE | NOT NULL |
| lab | VARCHAR(255) | |
| compliant | BOOLEAN | |
| report_url | VARCHAR(500) | |
| created_at | TIMESTAMP | DEFAULT NOW() |

### assessments (Lead Intake)
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| reference | VARCHAR(20) | UNIQUE, NOT NULL |
| contact_name | VARCHAR(255) | NOT NULL |
| contact_phone | VARCHAR(20) | NOT NULL |
| contact_email | VARCHAR(255) | |
| preferred_contact | ENUM | whatsapp, email, sms, phone |
| property_address | VARCHAR(500) | NOT NULL |
| suburb | VARCHAR(100) | NOT NULL |
| city | VARCHAR(100) | NOT NULL |
| property_type | ENUM | residential, commercial, industrial, agricultural |
| size_hectares | DECIMAL(8,2) | |
| estimated_value | DECIMAL(12,2) | |
| issue_category | VARCHAR(100) | NOT NULL |
| urgency | ENUM | emergency, high, medium, low, planning |
| description | TEXT | NOT NULL |
| has_existing_borehole | BOOLEAN | DEFAULT FALSE |
| borehole_depth | DECIMAL(8,2) | |
| pump_type | VARCHAR(100) | |
| pump_age | INT | |
| last_service_date | DATE | |
| has_filtration | BOOLEAN | DEFAULT FALSE |
| has_storage_tank | BOOLEAN | DEFAULT FALSE |
| lead_score | INT | |
| status | ENUM | new, contacted, scheduled, converted, closed |
| converted_job_id | UUID | FK -> jobs |
| consent | BOOLEAN | NOT NULL |
| created_at | TIMESTAMP | DEFAULT NOW() |

### invoices
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| job_id | UUID | FK -> jobs |
| subscription_id | UUID | FK -> subscriptions |
| property_id | UUID | FK -> properties, NOT NULL |
| invoice_number | VARCHAR(20) | UNIQUE, NOT NULL |
| issue_date | DATE | NOT NULL |
| due_date | DATE | NOT NULL |
| subtotal | DECIMAL(10,2) | NOT NULL |
| tax_rate | DECIMAL(5,2) | DEFAULT 15.00 |
| tax_amount | DECIMAL(10,2) | |
| total | DECIMAL(10,2) | NOT NULL |
| amount_paid | DECIMAL(10,2) | DEFAULT 0 |
| status | ENUM | draft, sent, paid, overdue, cancelled |
| created_at | TIMESTAMP | DEFAULT NOW() |

### subscriptions
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| property_id | UUID | FK -> properties, NOT NULL |
| plan_id | UUID | FK -> plans, NOT NULL |
| status | ENUM | active, paused, cancelled, expired |
| start_date | DATE | NOT NULL |
| next_billing_date | DATE | NOT NULL |
| payment_method | VARCHAR(50) | |
| created_at | TIMESTAMP | DEFAULT NOW() |

### plans
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| name | VARCHAR(100) | NOT NULL |
| description | TEXT | |
| price_monthly | DECIMAL(10,2) | NOT NULL |
| price_yearly | DECIMAL(10,2) | |
| services_per_year | INT | |
| water_tests_per_year | INT | |
| priority_level | ENUM | standard, priority, emergency |
| features | JSONB | |
| active | BOOLEAN | DEFAULT TRUE |

### certifications
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| technician_id | UUID | FK -> users, NOT NULL |
| name | VARCHAR(255) | NOT NULL |
| issuer | VARCHAR(255) | NOT NULL |
| issue_date | DATE | NOT NULL |
| expiry_date | DATE | |
| certificate_url | VARCHAR(500) | |
| verified | BOOLEAN | DEFAULT FALSE |

### notifications
| Column | Type | Constraints |
|--------|------|-------------|
| id | UUID | PK |
| user_id | UUID | FK -> users, NOT NULL |
| type | VARCHAR(50) | NOT NULL |
| title | VARCHAR(255) | NOT NULL |
| body | TEXT | NOT NULL |
| data | JSONB | |
| read | BOOLEAN | DEFAULT FALSE |
| priority | ENUM | high, normal, low |
| created_at | TIMESTAMP | DEFAULT NOW() |

## Indexes

- `users`: email (unique), role, current_status
- `properties`: owner_id, city, suburb
- `jobs`: property_id, technician_id, status, scheduled_date, urgency
- `jobs`: reference_number (unique)
- `water_quality_reports`: borehole_id, test_date
- `assessments`: status, lead_score, created_at
- `invoices`: property_id, status, due_date
- `job_timeline`: job_id, created_at

## Row Level Security (RLS) Policies

- Clients can only see their own properties, jobs, invoices
- Technicians can see assigned jobs and their own profile
- Dispatchers can see all jobs and technician locations
- Admins have full access
- Assessments (leads) are visible to dispatchers and admins until assigned
