import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  const { user_id, title, body, data, priority = 'normal' } = await req.json()

  // Store notification in database
  const { data: notification, error } = await supabase
    .from('notifications')
    .insert({
      user_id,
      type: 'status_update',
      title,
      body,
      data: data || {},
      priority
    })
    .select()
    .single()

  if (error) {
    return new Response(JSON.stringify({ error: error.message }), { status: 500 })
  }

  // Get user's push subscription (if exists)
  const { data: user } = await supabase
    .from('users')
    .select('preferences')
    .eq('id', user_id)
    .single()

  // Send push notification if user has enabled push
  if (user?.preferences?.push_enabled) {
    // In production, integrate with Firebase Cloud Messaging or OneSignal
    // const fcmResponse = await fetch('https://fcm.googleapis.com/fcm/send', {...})
    console.log(`Push notification sent to user ${user_id}: ${title}`)
  }

  // Send WhatsApp notification if preferred
  if (user?.preferences?.whatsapp_notifications) {
    // In production, integrate with Twilio or WhatsApp Business API
    console.log(`WhatsApp notification sent to user ${user_id}: ${title}`)
  }

  // Send SMS for high priority
  if (priority === 'high' && user?.preferences?.sms_notifications) {
    // In production, integrate with Twilio or Clickatell
    console.log(`SMS notification sent to user ${user_id}: ${title}`)
  }

  return new Response(JSON.stringify({
    success: true,
    notification,
    channels: ['in_app', 'push', 'whatsapp', 'sms'].filter(c => {
      if (c === 'push') return user?.preferences?.push_enabled
      if (c === 'whatsapp') return user?.preferences?.whatsapp_notifications
      if (c === 'sms') return priority === 'high' && user?.preferences?.sms_notifications
      return true // in_app always
    })
  }), { status: 200 })
})
