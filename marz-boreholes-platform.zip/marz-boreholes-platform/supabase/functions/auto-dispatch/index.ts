import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  const { job_id } = await req.json()

  // Get job details with property location
  const { data: job, error: jobError } = await supabase
    .from('jobs')
    .select('*, properties(*)')
    .eq('id', job_id)
    .single()

  if (jobError || !job) {
    return new Response(JSON.stringify({ error: 'Job not found' }), { status: 404 })
  }

  // Get dispatch recommendations from database function
  const { data: recommendations, error: recError } = await supabase
    .rpc('get_dispatch_recommendations', { job_uuid: job_id })

  if (recError || !recommendations || recommendations.length === 0) {
    return new Response(JSON.stringify({ error: 'No available technicians' }), { status: 404 })
  }

  // Select best technician (first in ordered list)
  const bestTech = recommendations[0]

  // Assign job to technician
  const { data: updatedJob, error: updateError } = await supabase
    .from('jobs')
    .update({ 
      technician_id: bestTech.technician_id,
      status: 'dispatched',
      updated_at: new Date().toISOString()
    })
    .eq('id', job_id)
    .select()
    .single()

  if (updateError) {
    return new Response(JSON.stringify({ error: updateError.message }), { status: 500 })
  }

  // Update technician status
  await supabase
    .from('users')
    .update({ current_status: 'en_route', current_job_id: job_id })
    .eq('id', bestTech.technician_id)

  // Create notification for technician
  await supabase
    .from('notifications')
    .insert({
      user_id: bestTech.technician_id,
      type: 'job_assigned',
      title: 'New Job Assigned',
      body: `Job ${job.reference_number}: ${job.description.substring(0, 100)}...`,
      data: { job_id, property_id: job.property_id },
      priority: job.urgency === 'emergency' ? 'high' : 'normal'
    })

  // Create notification for client
  const { data: property } = await supabase
    .from('properties')
    .select('owner_id')
    .eq('id', job.property_id)
    .single()

  if (property) {
    await supabase
      .from('notifications')
      .insert({
        user_id: property.owner_id,
        type: 'job_assigned',
        title: 'Technician Assigned',
        body: `${bestTech.technician_name} has been assigned to your job.`,
        data: { job_id, technician_id: bestTech.technician_id },
        priority: 'normal'
      })
  }

  return new Response(JSON.stringify({
    success: true,
    job: updatedJob,
    assigned_technician: {
      id: bestTech.technician_id,
      name: bestTech.technician_name,
      distance_km: bestTech.distance_km,
      priority_score: bestTech.priority_score
    }
  }), { status: 200 })
})
