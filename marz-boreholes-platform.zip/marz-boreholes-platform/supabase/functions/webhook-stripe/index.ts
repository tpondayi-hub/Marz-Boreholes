import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const stripeWebhookSecret = Deno.env.get('STRIPE_WEBHOOK_SECRET')!

const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  const signature = req.headers.get('stripe-signature')
  const body = await req.text()

  // In production, verify Stripe signature
  // const event = stripe.webhooks.constructEvent(body, signature, stripeWebhookSecret)

  // For demo, parse the event directly
  const event = JSON.parse(body)

  switch (event.type) {
    case 'invoice.payment_succeeded': {
      const invoice = event.data.object

      // Update invoice status
      await supabase
        .from('invoices')
        .update({ status: 'paid', amount_paid: invoice.amount_paid / 100 })
        .eq('invoice_number', invoice.metadata.invoice_number)

      // Create notification
      const { data: property } = await supabase
        .from('invoices')
        .select('property_id')
        .eq('invoice_number', invoice.metadata.invoice_number)
        .single()

      if (property) {
        const { data: owner } = await supabase
          .from('properties')
          .select('owner_id')
          .eq('id', property.property_id)
          .single()

        if (owner) {
          await supabase
            .from('notifications')
            .insert({
              user_id: owner.owner_id,
              type: 'payment_received',
              title: 'Payment Received',
              body: `Your payment of R${(invoice.amount_paid / 100).toFixed(2)} has been received.`,
              data: { invoice_number: invoice.metadata.invoice_number },
              priority: 'normal'
            })
        }
      }
      break
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object

      await supabase
        .from('invoices')
        .update({ status: 'overdue' })
        .eq('invoice_number', invoice.metadata.invoice_number)

      // Notify client of failed payment
      console.log(`Payment failed for invoice ${invoice.metadata.invoice_number}`)
      break
    }

    case 'customer.subscription.created': {
      const subscription = event.data.object

      await supabase
        .from('subscriptions')
        .update({ status: 'active' })
        .eq('id', subscription.metadata.subscription_id)

      console.log(`Subscription created: ${subscription.id}`)
      break
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object

      await supabase
        .from('subscriptions')
        .update({ status: 'cancelled' })
        .eq('id', subscription.metadata.subscription_id)

      console.log(`Subscription cancelled: ${subscription.id}`)
      break
    }
  }

  return new Response(JSON.stringify({ received: true }), { status: 200 })
})
