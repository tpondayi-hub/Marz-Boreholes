import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!

const supabase = createClient(supabaseUrl, supabaseServiceKey)

serve(async (req) => {
  const { assessment_id } = await req.json()

  // Get assessment details
  const { data: assessment, error } = await supabase
    .from('assessments')
    .select('*')
    .eq('id', assessment_id)
    .single()

  if (error || !assessment) {
    return new Response(JSON.stringify({ error: 'Assessment not found' }), { status: 404 })
  }

  // Determine response time based on urgency
  const responseTime = {
    'emergency': '2 hours',
    'high': 'Same day',
    'medium': '24-48 hours',
    'low': 'Within 1 week',
    'planning': 'Within 2 weeks'
  }[assessment.urgency] || 'Within 1 week'

  // Create notification for dispatchers
  const { data: dispatchers } = await supabase
    .from('users')
    .select('id')
    .eq('role', 'dispatcher')

  if (dispatchers) {
    const notifications = dispatchers.map(d => ({
      user_id: d.id,
      type: 'emergency_alert',
      title: `New ${assessment.urgency} assessment`,
      body: `${assessment.contact_name} - ${assessment.issue_category} (${assessment.suburb})`,
      data: { assessment_id, lead_score: assessment.lead_score },
      priority: assessment.urgency === 'emergency' ? 'high' : 'normal'
    }))

    await supabase.from('notifications').insert(notifications)
  }

  // Auto-convert high-score assessments to jobs if emergency
  if (assessment.urgency === 'emergency' && assessment.lead_score >= 70) {
    // Create property first (if assessment includes property details)
    const { data: property } = await supabase
      .from('properties')
      .insert({
        owner_id: null, // Will be linked after client registration
        name: assessment.contact_name + ' Residence',
        address: assessment.property_address,
        suburb: assessment.suburb,
        city: assessment.city,
        type: assessment.property_type
      })
      .select()
      .single()

    if (property) {
      // Create job from assessment
      const { data: job } = await supabase
        .from('jobs')
        .insert({
          property_id: property.id,
          type: 'emergency',
          urgency: 'emergency',
          description: assessment.description,
          status: 'pending'
        })
        .select()
        .single()

      if (job) {
        await supabase
          .from('assessments')
          .update({ status: 'converted', converted_job_id: job.id })
          .eq('id', assessment_id)
      }
    }
  }

  return new Response(JSON.stringify({
    success: true,
    assessment: {
      id: assessment.id,
      reference: assessment.reference,
      lead_score: assessment.lead_score,
      estimated_response_time: responseTime,
      status: assessment.status
    }
  }), { status: 200 })
})
