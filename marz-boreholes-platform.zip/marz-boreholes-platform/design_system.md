# Marz Boreholes - Design System

## Overview

A comprehensive design system for the Marz Boreholes field service management platform. Built for mobile-first technician workflows and desktop admin dashboards.

---

## Color Palette

### Primary Colors
| Token | Hex | Usage |
|-------|-----|-------|
| `--primary` | `#0066CC` | Primary actions, links, active states |
| `--primary-dark` | `#004C99` | Hover states, gradients |
| `--secondary` | `#00AA66` | Success, completion, positive indicators |

### Semantic Colors
| Token | Hex | Usage |
|-------|-----|-------|
| `--accent` | `#FF6B35` | Warnings, urgent items, highlights |
| `--danger` | `#DC3545` | Errors, emergencies, deletions |
| `--warning` | `#FFC107` | Cautions, medium priority |
| `--success` | `#28A745` | Success messages, online status |
| `--info` | `#17A2B8` | Information, neutral priority |

### Neutral Colors
| Token | Hex | Usage |
|-------|-----|-------|
| `--bg` | `#F5F7FA` | Mobile app backgrounds |
| `--bg-dark` | `#F0F2F5` | Desktop admin backgrounds |
| `--surface` | `#FFFFFF` | Cards, panels, inputs |
| `--text` | `#1A1D2B` | Primary text |
| `--text-secondary` | `#6B7280` | Secondary text, labels |
| `--border` | `#E5E7EB` | Dividers, borders, input outlines |

### Color Usage Patterns
- **Emergency**: `--danger` background tint (`#FFEBEE`) + `--danger` text
- **High Priority**: `--warning` background tint (`#FFF3E0`) + `--accent` text
- **Medium Priority**: `--accent` background tint + `--accent` text
- **Low Priority**: `--info` background tint (`#E3F2FD`) + `--info` text
- **Success/Active**: `--success` background tint (`#E8F5E9`) + `--success` text
- **Primary/Selected**: `--primary` background tint (`#E8F4FD`) + `--primary` text

---

## Typography

### Font Family
- **Primary**: `Inter` (Google Fonts) - weights 400, 500, 600, 700, 800
- **Fallback**: `system-ui, -apple-system, sans-serif`

### Type Scale
| Token | Size | Weight | Usage |
|-------|------|--------|-------|
| `hero-title` | 48px | 900 | Landing page headlines |
| `page-title` | 28px | 800 | Page headers |
| `section-title` | 18px | 700 | Section headers |
| `card-title` | 16px | 700 | Card headings |
| `body` | 14px | 400-500 | Body text |
| `caption` | 12px | 500 | Labels, timestamps |
| `badge` | 11px | 700 | Status badges, tags |

### Text Styles
- **Uppercase labels**: `text-transform: uppercase; letter-spacing: 0.5px;` for form labels, section labels
- **Stat numbers**: `font-weight: 800; font-size: 24-28px;`
- **Currency**: `font-weight: 700;` prefixed with `R` (South African Rand)

---

## Spacing System

### Base Unit: 4px
| Token | Value | Usage |
|-------|-------|-------|
| `xs` | 4px | Tight gaps, icon padding |
| `sm` | 8px | Small gaps, inline spacing |
| `md` | 12px | Card padding, button gaps |
| `lg` | 16px | Section padding, grid gaps |
| `xl` | 20px | Page padding, card margins |
| `2xl` | 24px | Large sections, hero padding |
| `3xl` | 32px | Major section breaks |

### Mobile Frame
- **Container**: `max-width: 414px` (iPhone Max width)
- **Frame border**: `8px solid #1a1a1a` (phone bezel)
- **Border radius**: `40px` (rounded corners)
- **Notch**: `150px x 30px` centered at top
- **Safe area**: `padding: 0 20px` for content

---

## Shadows

| Token | Value | Usage |
|-------|-------|-------|
| `--shadow` | `0 2px 8px rgba(0,0,0,0.08)` | Cards, buttons |
| `--shadow-lg` | `0 4px 16px rgba(0,0,0,0.12)` | Modals, phone frame, elevated cards |
| `--shadow-nav` | `0 -4px 16px rgba(0,0,0,0.06)` | Bottom navigation |

---

## Components

### Buttons

**Primary Button**
- Background: `linear-gradient(135deg, var(--primary), var(--primary-dark))`
- Color: white
- Padding: `16px`
- Border-radius: `12px`
- Font: `15px, weight 700`
- Shadow: `0 4px 12px rgba(0,102,204,0.3)`
- Active: `transform: scale(0.98)`

**Secondary Button**
- Background: `var(--bg)`
- Border: `2px solid var(--border)`
- Color: `var(--text)`
- Same padding/radius as primary

**Success Button**
- Background: `linear-gradient(135deg, var(--success), #1E7E34)`
- Shadow: `0 4px 12px rgba(40,167,69,0.3)`

**Action Button (Mobile)**
- Flex: 1
- Height: auto (padding-based)
- Icon + text layout

### Cards

**Standard Card**
- Background: `var(--surface)`
- Border-radius: `16px`
- Padding: `16px`
- Shadow: `var(--shadow)`
- Active: `transform: scale(0.98)`

**Property Card**
- Header: icon + name + status badge
- Stats row: 4 columns with value + label
- Border-top divider for stats

**Job Card**
- Time column (left, centered)
- Status badge below time
- Details column (type, location, suburb)
- Chevron right indicator
- Color-coded left border for urgency

**Timeline Card**
- Dot indicator with color coding
- Type + date header
- Technician info with avatar
- Description text
- Footer: cost + rating + status

### Inputs

**Text Input**
- Background: `var(--surface)`
- Border: `2px solid var(--border)`
- Border-radius: `12px`
- Padding: `14px 16px`
- Font: `15px`
- Focus: `border-color: var(--primary); box-shadow: 0 0 0 4px rgba(0,102,204,0.08)`
- Placeholder: `color: var(--text-secondary); opacity: 0.5`

**Textarea**
- Same as text input
- Min-height: `100px`
- Resize: vertical

**Select**
- Appearance: none
- Custom chevron icon (SVG data URI)
- Padding-right: `44px` for icon space

### Badges & Tags

**Status Badge**
- Padding: `4px 10px`
- Border-radius: `20px`
- Font: `11px, weight 700, uppercase`
- Background: tinted version of semantic color
- Color: solid semantic color

**Skill Tag**
- Padding: `8px 14px`
- Border-radius: `20px`
- Font: `13px, weight 600`
- Background: `#E8F4FD`
- Color: `var(--primary)`

**Feature Tag**
- Padding: `4px 10px`
- Border-radius: `6px`
- Font: `12px`
- Background: `var(--surface-light)`
- Color: `var(--text-secondary)`

### Navigation

**Bottom Nav (Mobile)**
- Position: fixed bottom
- Background: `var(--surface)`
- Border-top: `1px solid var(--border)`
- Shadow: `0 -4px 16px rgba(0,0,0,0.06)`
- Padding: `12px 0 28px` (safe area)
- Items: icon (22px) + label (11px)
- Active: `color: var(--primary)`

**Sidebar (Desktop)**
- Width: `260px`
- Fixed position
- Background: `var(--surface)`
- Border-right: `1px solid var(--border)`
- Active item: `background: #E8F4FD; border-left: 3px solid var(--primary)`

### Progress Indicators

**Step Progress**
- Dots: `34px` circles
- Active: `background: var(--primary); color: white; box-shadow: 0 0 0 4px rgba(0,102,204,0.15)`
- Completed: `background: var(--success); color: white`
- Pending: `background: var(--surface); border: 2px solid var(--border)`
- Connecting line: `3px` height, gradient from primary to secondary
- Labels: `10px, uppercase, letter-spacing: 0.5px`

**Status Progress Bar**
- 4 steps: Dispatched → En Route → On Site → Complete
- Dots: `36px` circles
- Completed: green checkmark
- Active: pulsing blue with ring animation
- Pending: gray outline
- Connecting line: `3px` with fill animation

### Toggle Switches

- Track: `52px x 30px`, border-radius `15px`
- Background: `var(--border)` (off) / `var(--primary)` (on)
- Thumb: `26px` circle, white, shadow
- Transition: `0.3s` for both background and thumb position
- Transform on: `translateX(22px)`

---

## Animations

### Entrance Animations
| Name | Effect | Duration | Delay |
|------|--------|----------|-------|
| `slideUp` | `translateY(20px) → 0, opacity 0 → 1` | `0.4s ease-out` | staggered 0.1s |
| `slideInRight` | `translateX(30px) → 0, opacity 0 → 1` | `0.4s ease-out` | per step |

### Micro-interactions
| Element | Effect | Duration |
|---------|--------|----------|
| Card press | `scale(0.98)` | `0.2s` |
| Button press | `scale(0.96)` | `0.2s` |
| Rating button | `scale(0.9)` | `0.2s` |
| Toggle switch | `transform` thumb | `0.3s` |
| Queue item hover | `translateX(4px)` + shadow | `0.2s` |
| Map marker hover | `scale(1.1)` | `0.2s` |

### Continuous Animations
| Name | Effect | Duration |
|------|--------|----------|
| `pulse` | opacity `1 → 0.4 → 1` | `2s infinite` |
| `pulse-ring` | box-shadow expand `4px → 12px` | `2s infinite` |

---

## Icons

- **Library**: Font Awesome 6.4.0 (CDN)
- **Size scale**: 12px (badges) → 14px (buttons) → 18px (cards) → 22px (nav) → 28px (hero)
- **Color**: Inherits from parent or uses semantic color
- **Common icons**:
  - Water: `fa-water`
  - Jobs: `fa-wrench`, `fa-tools`
  - Location: `fa-map-marker-alt`, `fa-map-marked-alt`
  - Status: `fa-check-circle`, `fa-exclamation-circle`, `fa-clock`
  - Navigation: `fa-arrow-left`, `fa-arrow-right`, `fa-chevron-right`
  - Actions: `fa-plus`, `fa-filter`, `fa-download`
  - User: `fa-user`, `fa-user-circle`, `fa-hard-hat`
  - Communication: `fa-phone`, `fa-envelope`, `fa-comment`
  - Documentation: `fa-camera`, `fa-file-alt`, `fa-clipboard-check`

---

## Responsive Breakpoints

| Breakpoint | Width | Target |
|------------|-------|--------|
| Mobile | < 640px | Technician app, client app |
| Tablet | 640-1024px | Tablet views, split layouts |
| Desktop | > 1024px | Admin dashboard, dispatch board |

---

## Accessibility

- Minimum contrast ratio: 4.5:1 for text
- Focus states: visible outline on all interactive elements
- Touch targets: minimum 44px for mobile
- Reduced motion: respect `prefers-reduced-motion`
- Screen reader: semantic HTML, ARIA labels on icons
